// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class SAr extends S {
  SAr([String locale = 'ar']) : super(locale);

  @override
  String get appName => 'مشينا';

  @override
  String get appDescription => 'مرحبا بك في مشينا';

  @override
  String get commonOk => 'موافق';

  @override
  String get commonCancel => 'إلغاء';

  @override
  String get enableLocationBannerTitle => 'فعّل الموقع لتحديد موقعك تلقائيًا';

  @override
  String get enableLocationButton => 'تفعيل';

  @override
  String get locationServiceOffTitle => 'خدمة الموقع غير مفعّلة';

  @override
  String get openSettingsButton => 'فتح الإعدادات';

  @override
  String get commonYes => 'نعم';

  @override
  String get commonNo => 'لا';

  @override
  String get commonNext => 'التالي';

  @override
  String get commonBack => 'رجوع';

  @override
  String get commonSkip => 'تخطي';

  @override
  String get commonConfirm => 'تأكيد';

  @override
  String get commonSave => 'حفظ';

  @override
  String get commonSelected => 'مختار';

  @override
  String get commonLoading => 'جاري التحميل...';

  @override
  String get commonError => 'حدث خطأ ما';

  @override
  String get commonRetry => 'إعادة المحاولة';

  @override
  String get onboardingTitle1 => 'احجز رحلتك في أي وقت';

  @override
  String get onboardingSubtitle1 =>
      'اعثر على سائق قريب واحجز رحلتك خلال ثوانٍ.';

  @override
  String get onboardingTitle2 => 'تتبّع سائقك مباشرة';

  @override
  String get onboardingSubtitle2 => 'شاهد موقع السائق ووقت وصوله لحظة بلحظة.';

  @override
  String get onboardingTitle3 => 'دفع سهل وآمن';

  @override
  String get onboardingSubtitle3 => 'ادفع نقدًا أو إلكترونيًا بكل أمان وراحة.';

  @override
  String get authLogin => 'تسجيل الدخول';

  @override
  String get enterYourNumberLogin => 'ادخل رقمك لتسجيل الدخول';

  @override
  String get enterYourNumberRegister => 'Enter your number to sign up';

  @override
  String get enterYourEmailLogin => 'ادخل بريدك الالكتروني لتسجيل الدخول';

  @override
  String get enterYourEmailRegister => 'ادخل بريدك الالكتروني للتسجيل';

  @override
  String get enterDestination => 'ادخل وجهة';

  @override
  String get authRegister => 'إنشاء حساب';

  @override
  String get authLogout => 'تسجيل الخروج';

  @override
  String get authSendCode => 'ارسل رمز التحقق';

  @override
  String get authDontHaveAnAccount => 'ليس لديك حساب؟';

  @override
  String get authPhone => 'رقم الهاتف';

  @override
  String get authSignUp => 'تسجيل';

  @override
  String get authPassword => 'كلمة المرور';

  @override
  String get authForgotPassword => 'نسيت كلمة المرور؟';

  @override
  String get authOtpTitle => 'رمز التحقق';

  @override
  String get authOtpSubtitle => 'أدخل الرمز المرسل إلى رقمك';

  @override
  String get authResendOtp => 'إعادة إرسال الرمز';

  @override
  String get authOtpSuccess => 'تم تأكيد رمز التحقق';

  @override
  String get otpResendSuccess => 'تم ارسال رمز التحقق بنجاح';

  @override
  String get homeWhereTo => 'إلى أين تريد الذهاب؟';

  @override
  String get homeCurrentLocation => 'موقعي الحالي';

  @override
  String get homeSearchDestination => 'ابحث عن وجهة';

  @override
  String get noInternetConnection => 'لا يوجد اتصال بالإنترنت';

  @override
  String get makeSureInternetConnection =>
      'يرجى التحقق من اتصالك بالإنترنت والمحاولة مرة أخرى';

  @override
  String get rideRequestRide => 'طلب رحلة';

  @override
  String get rideFindingDriver => 'جارٍ البحث عن سائق...';

  @override
  String get rideDriverOnWay => 'السائق في الطريق';

  @override
  String get rideDriverArrived => 'وصل السائق';

  @override
  String get rideTripStarted => 'بدأت الرحلة';

  @override
  String get rideTripEnded => 'انتهت الرحلة';

  @override
  String get rideCancelRide => 'إلغاء الرحلة';

  @override
  String get rideEstimatedTime => 'الوقت المتوقع';

  @override
  String get rideEstimatedPrice => 'السعر المتوقع';

  @override
  String get paymentPaymentMethod => 'طريقة الدفع';

  @override
  String get paymentCash => 'نقدًا';

  @override
  String get paymentOnline => 'دفع إلكتروني';

  @override
  String get paymentTotal => 'المجموع';

  @override
  String get paymentPayNow => 'ادفع الآن';

  @override
  String get paymentSuccess => 'تم الدفع بنجاح';

  @override
  String get paymentFailed => 'فشل الدفع';

  @override
  String get ratingRateDriver => 'قيّم السائق';

  @override
  String get ratingLeaveComment => 'اكتب تعليقًا (اختياري)';

  @override
  String get ratingSubmitRating => 'إرسال التقييم';

  @override
  String get profileProfile => 'الملف الشخصي';

  @override
  String get profileEditProfile => 'تعديل الملف الشخصي';

  @override
  String get profileName => 'الاسم';

  @override
  String get email => 'البريد الإلكتروني';

  @override
  String get profileLanguage => 'اللغة';

  @override
  String get profileNotifications => 'الإشعارات';

  @override
  String get profilePrivacy => 'الخصوصية';

  @override
  String get settingsSettings => 'الإعدادات';

  @override
  String get settingsDarkMode => 'الوضع الليلي';

  @override
  String get settingsChangeLanguage => 'تغيير اللغة';

  @override
  String get settingsAboutApp => 'حول التطبيق';

  @override
  String get errorsNetwork => 'تحقق من اتصال الإنترنت';

  @override
  String get errorsUnauthorized => 'غير مصرح لك';

  @override
  String get errorsLocationPermission => 'يرجى السماح بالوصول إلى الموقع';

  @override
  String get apiConnectionTimeout => 'انتهت مهلة الاتصال';

  @override
  String get apiSendTimeout => 'انتهت مهلة الإرسال';

  @override
  String get apiReceiveTimeout => 'انتهت مهلة الاستلام';

  @override
  String get apiRequestCancelled => 'تم إلغاء الطلب';

  @override
  String get apiConnectionError => 'خطأ في الاتصال';

  @override
  String get apiCertificateError => 'خطأ في الشهادة';

  @override
  String get apiBadRequest => 'طلب غير صالح';

  @override
  String get apiUnauthorized => 'غير مصرح';

  @override
  String get apiForbidden => 'ممنوع';

  @override
  String get apiNotFound => 'غير موجود';

  @override
  String get apiValidationError => 'خطأ في التحقق من البيانات';

  @override
  String get apiServerError => 'خطأ في الخادم';

  @override
  String get apiBadGateway => 'بوابة غير صالحة';

  @override
  String get apiServiceUnavailable => 'الخدمة غير متاحة';

  @override
  String apiRequestFailed(Object code) {
    return 'فشل الطلب ($code)';
  }

  @override
  String get otpTitle => 'أدخل رمز التحقق';

  @override
  String get alreadyHaveAnAccount => 'لديك حساب؟';

  @override
  String get confirmPassword => 'تاكيد كلمة المرور';

  @override
  String otpSubtitle(Object phone) {
    return 'تم إرسال رمز إلى $phone';
  }

  @override
  String get otpDidNotReceive => 'لم يصلك الرمز؟';

  @override
  String get otpResend => 'إعادة الإرسال';

  @override
  String get otpVerifyNow => 'تحقق الآن';

  @override
  String get apiUnknownError => 'خطأ غير معروف';

  @override
  String get cacheError => 'خطأ في التخزين';

  @override
  String get validationRequired => 'هذا الحقل مطلوب';

  @override
  String get validationInvalidEmail => 'بريد إلكتروني غير صالح';

  @override
  String get validationInvalidPhone => 'رقم هاتف غير صالح';

  @override
  String get validationWeakPassword =>
      'كلمة مرور ضعيفة (حرف كبير، صغير، رقم، رمز)';

  @override
  String get validationOtpInvalid => 'رمز غير صالح';

  @override
  String validationMinLength(int min) {
    return 'الحد الأدنى $min أحرف';
  }

  @override
  String get validationPasswordsNotMatch => 'Passwords do not match';

  @override
  String validationMaxLength(int max) {
    return 'الحد الأقصى $max أحرف';
  }

  @override
  String get locationPermissionRationaleTitle => 'الوصول إلى الموقع';

  @override
  String get locationPermissionRationaleBody =>
      'يحتاج تطبيق مشينا إلى موقعك لعرض موقعك على الخريطة، وتحديد نقطة الالتقاط تلقائيًا، وربطك بالسائقين القريبين.';

  @override
  String get locationPermissionAllow => 'السماح';

  @override
  String get locationPermissionDeniedForeverTitle => 'إذن الموقع مطلوب';

  @override
  String get locationPermissionDeniedForeverBody =>
      'لقد رفضت إذن الموقع بشكل دائم. يرجى فتح الإعدادات وتفعيله يدويًا.';

  @override
  String get mapDragToMovePin => 'اسحب الخريطة لتحريك المؤشر';

  @override
  String get mapConfirmLocation => 'تأكيد الموقع';

  @override
  String get homeNowYouCanAddMultipleStops => 'الآن يمكنك إضافة عدة وجهات';

  @override
  String get rideAvailableRides => 'الرحلات المتاحة';

  @override
  String get rideBookRide => 'احجز رحلة';

  @override
  String get rideNoTypesAvailable => 'لا توجد أنواع رحلات متاحة الآن.';

  @override
  String rideDistanceKm(String distance) {
    return '$distance كم';
  }

  @override
  String rideDurationMin(String duration) {
    return '$duration دقيقة';
  }

  @override
  String rideStopsCount(int count) {
    return '$count محطة';
  }

  @override
  String get ridePersonCapacity => '4+1 شخص';

  @override
  String get homeMapRouteUnavailable =>
      'مسار الخريطة غير متاح حالياً. العلامات توضح توقفات رحلتك.';

  @override
  String get rideConfirmed => 'تم تأكيد الرحلة';

  @override
  String get driverRating => 'التقييم';

  @override
  String get driverTrips => 'الرحلات';

  @override
  String get driverYears => 'سنوات';

  @override
  String get driverVehicleDetails => 'تفاصيل المركبة';

  @override
  String get driverLicensePlate => 'رقم اللوحة';

  @override
  String get commonClose => 'إغلاق';

  @override
  String get rideEstFare => 'السعر التقديري';

  @override
  String get rideDistance => 'المسافة';

  @override
  String get rideDuration => 'المدة';

  @override
  String get commonPleaseWait => 'يرجى الانتظار';

  @override
  String get rideLookingForDrivers => 'جارٍ البحث عن سائقين قريبين...';

  @override
  String get rideTakesFewMoments => 'يستغرق هذا عادة بضع لحظات';

  @override
  String get simulateEndTrip => 'محاكاة إنهاء الرحلة';

  @override
  String get tripCancelledByDriver => 'Trip cancelled by driver';

  @override
  String get tripCancelledByAdmin => 'Trip cancelled by admin';

  @override
  String get tripCancelled => 'Trip cancelled';

  @override
  String get logoutConfirmationMessage =>
      'هل ترغب في تسجيل الخروج من هذا الجهاز أو جميع الأجهزة؟';

  @override
  String get logoutThisDevice => 'هذا الجهاز';

  @override
  String get logoutAllDevices => 'جميع الأجهزة';

  @override
  String get drawerMyAccount => 'حسابي';

  @override
  String get drawerFavourites => 'المفضلة';

  @override
  String get drawerFaq => 'الأسئلة الشائعة';

  @override
  String get drawerSos => 'الطوارئ';

  @override
  String get drawerMakeComplaints => 'تقديم شكوى';

  @override
  String get drawerNotification => 'الإشعارات';

  @override
  String get drawerAbout => 'عن التطبيق';

  @override
  String get drawerPrivacyPolicy => 'سياسة الخصوصية';

  @override
  String get drawerTermsCondition => 'الشروط والأحكام';

  @override
  String get drawerGuestUser => 'مستخدم زائر';
}
