// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class SEn extends S {
  SEn([String locale = 'en']) : super(locale);

  @override
  String get appName => 'Mashena';

  @override
  String get appDescription => 'Welcome to Mashena';

  @override
  String get commonOk => 'OK';

  @override
  String get commonCancel => 'Cancel';

  @override
  String get enableLocationBannerTitle =>
      'Enable location to detect your pickup point automatically';

  @override
  String get enableLocationButton => 'Enable';

  @override
  String get locationServiceOffTitle => 'Location service is turned off';

  @override
  String get openSettingsButton => 'Open Settings';

  @override
  String get commonYes => 'Yes';

  @override
  String get commonNo => 'No';

  @override
  String get commonNext => 'Next';

  @override
  String get commonBack => 'Back';

  @override
  String get commonSkip => 'Skip';

  @override
  String get commonConfirm => 'Confirm';

  @override
  String get commonSave => 'Save';

  @override
  String get commonSelected => 'Selected';

  @override
  String get commonLoading => 'Loading...';

  @override
  String get commonError => 'Something went wrong';

  @override
  String get commonRetry => 'Retry';

  @override
  String get onboardingTitle1 => 'Book a Ride Anytime';

  @override
  String get onboardingSubtitle1 =>
      'Find a nearby driver and book your ride in seconds.';

  @override
  String get onboardingTitle2 => 'Track Your Driver Live';

  @override
  String get onboardingSubtitle2 =>
      'See your driver’s location and arrival time in real time.';

  @override
  String get onboardingTitle3 => 'Easy & Secure Payments';

  @override
  String get onboardingSubtitle3 =>
      'Pay cash or online with complete safety and comfort.';

  @override
  String get authLogin => 'Login';

  @override
  String get enterYourNumberLogin => 'Enter your number to login';

  @override
  String get enterYourNumberRegister => 'Enter your number to sign up';

  @override
  String get enterYourEmailLogin => 'Enter your email to login';

  @override
  String get enterYourEmailRegister => 'Enter your email to sign up';

  @override
  String get enterDestination => 'Enter Destination';

  @override
  String get authRegister => 'Create Account';

  @override
  String get authLogout => 'Logout';

  @override
  String get authSendCode => 'Send Code';

  @override
  String get authDontHaveAnAccount => 'Don\'t have an account?';

  @override
  String get authPhone => 'Phone Number';

  @override
  String get authSignUp => 'Sign Up';

  @override
  String get authPassword => 'Password';

  @override
  String get authForgotPassword => 'Forgot password?';

  @override
  String get authOtpTitle => 'Verification Code';

  @override
  String get authOtpSubtitle => 'Enter the code sent to your phone';

  @override
  String get authResendOtp => 'Resend Code';

  @override
  String get authOtpSuccess => 'Verification successful';

  @override
  String get otpResendSuccess => 'Code sent successfully';

  @override
  String get homeWhereTo => 'Where to?';

  @override
  String get homeCurrentLocation => 'Current location';

  @override
  String get homeSearchDestination => 'Search destination';

  @override
  String get noInternetConnection => 'No internet connection';

  @override
  String get makeSureInternetConnection =>
      'Please check your internet connection and try again.';

  @override
  String get rideRequestRide => 'Request Ride';

  @override
  String get rideFindingDriver => 'Finding a driver...';

  @override
  String get rideDriverOnWay => 'Driver is on the way';

  @override
  String get rideDriverArrived => 'Driver arrived';

  @override
  String get rideTripStarted => 'Trip started';

  @override
  String get rideTripEnded => 'Trip ended';

  @override
  String get rideCancelRide => 'Cancel Ride';

  @override
  String get rideEstimatedTime => 'Estimated time';

  @override
  String get rideEstimatedPrice => 'Estimated price';

  @override
  String get paymentPaymentMethod => 'Payment Method';

  @override
  String get paymentCash => 'Cash';

  @override
  String get paymentOnline => 'Online Payment';

  @override
  String get paymentTotal => 'Total';

  @override
  String get paymentPayNow => 'Pay Now';

  @override
  String get paymentSuccess => 'Payment successful';

  @override
  String get paymentFailed => 'Payment failed';

  @override
  String get ratingRateDriver => 'Rate Driver';

  @override
  String get ratingLeaveComment => 'Leave a comment (optional)';

  @override
  String get ratingSubmitRating => 'Submit Rating';

  @override
  String get profileProfile => 'Profile';

  @override
  String get profileEditProfile => 'Edit Profile';

  @override
  String get profileName => 'Name';

  @override
  String get email => 'Email';

  @override
  String get profileLanguage => 'Language';

  @override
  String get profileNotifications => 'Notifications';

  @override
  String get profilePrivacy => 'Privacy';

  @override
  String get settingsSettings => 'Settings';

  @override
  String get settingsDarkMode => 'Dark Mode';

  @override
  String get settingsChangeLanguage => 'Change Language';

  @override
  String get settingsAboutApp => 'About App';

  @override
  String get errorsNetwork => 'Check your internet connection';

  @override
  String get errorsUnauthorized => 'Unauthorized access';

  @override
  String get errorsLocationPermission => 'Please allow location access';

  @override
  String get apiConnectionTimeout => 'Connection timeout';

  @override
  String get apiSendTimeout => 'Send timeout';

  @override
  String get apiReceiveTimeout => 'Receive timeout';

  @override
  String get apiRequestCancelled => 'Request cancelled';

  @override
  String get apiConnectionError => 'Connection error';

  @override
  String get apiCertificateError => 'Certificate error';

  @override
  String get apiBadRequest => 'Bad request';

  @override
  String get apiUnauthorized => 'Unauthorized';

  @override
  String get apiForbidden => 'Forbidden';

  @override
  String get apiNotFound => 'Not found';

  @override
  String get apiValidationError => 'Validation error';

  @override
  String get apiServerError => 'Server error';

  @override
  String get apiBadGateway => 'Bad gateway';

  @override
  String get apiServiceUnavailable => 'Service unavailable';

  @override
  String apiRequestFailed(Object code) {
    return 'Request failed ($code)';
  }

  @override
  String get otpTitle => 'Enter verification code';

  @override
  String get alreadyHaveAnAccount => 'Already have an account?';

  @override
  String get confirmPassword => 'Confirm Password';

  @override
  String otpSubtitle(Object phone) {
    return 'A code has been sent to $phone';
  }

  @override
  String get otpDidNotReceive => 'Don\'t receive a code?';

  @override
  String get otpResend => 'Resend';

  @override
  String get otpVerifyNow => 'Verify Now';

  @override
  String get apiUnknownError => 'Unknown error';

  @override
  String get cacheError => 'Cache error';

  @override
  String get validationRequired => 'This field is required';

  @override
  String get validationInvalidEmail => 'Invalid email';

  @override
  String get validationInvalidPhone => 'Invalid phone number';

  @override
  String get validationWeakPassword =>
      'Weak password (uppercase, lowercase, number, symbol)';

  @override
  String get validationOtpInvalid => 'Invalid code';

  @override
  String validationMinLength(int min) {
    return 'Minimum $min characters';
  }

  @override
  String get validationPasswordsNotMatch => 'Passwords do not match';

  @override
  String validationMaxLength(int max) {
    return 'Maximum $max characters';
  }

  @override
  String get locationPermissionRationaleTitle => 'Location Access';

  @override
  String get locationPermissionRationaleBody =>
      'Mashena needs your location to show your position on the map, auto-detect your pickup point, and connect you with nearby drivers.';

  @override
  String get locationPermissionAllow => 'Allow';

  @override
  String get locationPermissionDeniedForeverTitle =>
      'Location Permission Required';

  @override
  String get locationPermissionDeniedForeverBody =>
      'You have permanently denied location access. Please open Settings and enable it manually.';

  @override
  String get mapDragToMovePin => 'Drag map to move pin';

  @override
  String get mapConfirmLocation => 'Confirm Location';

  @override
  String get homeNowYouCanAddMultipleStops => 'Now you can add multiple stops';

  @override
  String get rideAvailableRides => 'Available Rides';

  @override
  String get rideBookRide => 'Book Ride';

  @override
  String get rideNoTypesAvailable =>
      'No ride types available for this trip right now.';

  @override
  String rideDistanceKm(String distance) {
    return '$distance km';
  }

  @override
  String rideDurationMin(String duration) {
    return '$duration min';
  }

  @override
  String rideStopsCount(int count) {
    return '$count stop(s)';
  }

  @override
  String get ridePersonCapacity => '4+1 Person';

  @override
  String get homeMapRouteUnavailable =>
      'Map route currently unavailable. Markers show your trip stops.';

  @override
  String get rideConfirmed => 'Ride Confirmed';

  @override
  String get driverRating => 'Rating';

  @override
  String get driverTrips => 'Trips';

  @override
  String get driverYears => 'Years';

  @override
  String get driverVehicleDetails => 'Vehicle Details';

  @override
  String get driverLicensePlate => 'License Plate';

  @override
  String get commonClose => 'Close';

  @override
  String get rideEstFare => 'Est. Fare';

  @override
  String get rideDistance => 'Distance';

  @override
  String get rideDuration => 'Duration';

  @override
  String get commonPleaseWait => 'Please wait';

  @override
  String get rideLookingForDrivers => 'Looking for nearby drivers...';

  @override
  String get rideTakesFewMoments => 'This usually takes a few moments';

  @override
  String get simulateEndTrip => 'Simulate End Trip';

  @override
  String get tripCancelledByDriver => 'Trip cancelled by driver';

  @override
  String get tripCancelledByAdmin => 'Trip cancelled by admin';

  @override
  String get tripCancelled => 'Trip cancelled';

  @override
  String get logoutConfirmationMessage =>
      'Do you want to logout from this device or all devices?';

  @override
  String get logoutThisDevice => 'This Device';

  @override
  String get logoutAllDevices => 'All Devices';

  @override
  String get drawerMyAccount => 'My Account';

  @override
  String get drawerFavourites => 'Favourites';

  @override
  String get drawerFaq => 'FAQ';

  @override
  String get drawerSos => 'SOS';

  @override
  String get drawerMakeComplaints => 'Make Complaints';

  @override
  String get drawerNotification => 'Notification';

  @override
  String get drawerAbout => 'About';

  @override
  String get drawerPrivacyPolicy => 'Privacy Policy';

  @override
  String get drawerTermsCondition => 'Terms & Condition';

  @override
  String get drawerGuestUser => 'Guest User';

  @override
  String get rideLoadingDriverDetails => 'Loading driver details...';

  @override
  String rideVehicleModelAndColor(String vehicleModel, String vehicleColor) {
    return '$vehicleModel • $vehicleColor';
  }

  @override
  String get rideDriverArrivedAtPickup =>
      'Your driver has arrived at the pickup location!';

  @override
  String get rideWaitingChargesWarning =>
      '⚠️ Waiting charges may apply after the free wait timer expires.';

  @override
  String get rideInProgressHeadingToDestination =>
      'In Progress • Heading to Destination';

  @override
  String get rideWaitingChargesApplying =>
      '⏱️ 00:00 • Waiting charges are now applying';

  @override
  String rideFreeWaitingTime(String minutes, String seconds) {
    return '⏱️ Free waiting time: $minutes:$seconds';
  }

  @override
  String get rideVehicleDefault => 'Vehicle';

  @override
  String get rideVehicleStandard => 'Standard';

  @override
  String rideVehicleColorAndType(String color, String type) {
    return '$color • $type';
  }
}
