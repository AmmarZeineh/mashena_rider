enum AuthEvent { loggedOut, tokenRefreshed }
