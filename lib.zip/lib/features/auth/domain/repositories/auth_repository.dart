import 'package:dartz/dartz.dart';
import 'package:mashena_rider/core/errors/failure.dart';
import 'package:mashena_rider/features/auth/domain/entities/auth_session.dart';
import 'package:mashena_rider/features/auth/domain/entities/user.dart';

abstract class AuthRepository {
  Future<Either<Failure, User>> signup({
    required String email,
    required String password,
    required String fullName,
    required String phoneNumber,
  });

  Future<Either<Failure, AuthSession>> login({
    required String email,
    required String password,
    required String? fcmToken,
  });

  Future<Either<Failure, Unit>> sendOtp({String? email, String? phone});

  Future<Either<Failure, Unit>> verifyOtp({
    required String code,
    String? email,
    String? phone,
  });

  Future<Either<Failure, AuthSession>> getCachedSession();
  Future<Either<Failure, Unit>> logout();
  Future<Either<Failure, Unit>> logoutAll();
}
