// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'signup_request_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$SignupRequestDto {

 String get email; String get password; String get fullName; String get phoneNumber;
/// Create a copy of SignupRequestDto
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$SignupRequestDtoCopyWith<SignupRequestDto> get copyWith => _$SignupRequestDtoCopyWithImpl<SignupRequestDto>(this as SignupRequestDto, _$identity);

  /// Serializes this SignupRequestDto to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is SignupRequestDto&&(identical(other.email, email) || other.email == email)&&(identical(other.password, password) || other.password == password)&&(identical(other.fullName, fullName) || other.fullName == fullName)&&(identical(other.phoneNumber, phoneNumber) || other.phoneNumber == phoneNumber));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,email,password,fullName,phoneNumber);

@override
String toString() {
  return 'SignupRequestDto(email: $email, password: $password, fullName: $fullName, phoneNumber: $phoneNumber)';
}


}

/// @nodoc
abstract mixin class $SignupRequestDtoCopyWith<$Res>  {
  factory $SignupRequestDtoCopyWith(SignupRequestDto value, $Res Function(SignupRequestDto) _then) = _$SignupRequestDtoCopyWithImpl;
@useResult
$Res call({
 String email, String password, String fullName, String phoneNumber
});




}
/// @nodoc
class _$SignupRequestDtoCopyWithImpl<$Res>
    implements $SignupRequestDtoCopyWith<$Res> {
  _$SignupRequestDtoCopyWithImpl(this._self, this._then);

  final SignupRequestDto _self;
  final $Res Function(SignupRequestDto) _then;

/// Create a copy of SignupRequestDto
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? email = null,Object? password = null,Object? fullName = null,Object? phoneNumber = null,}) {
  return _then(_self.copyWith(
email: null == email ? _self.email : email // ignore: cast_nullable_to_non_nullable
as String,password: null == password ? _self.password : password // ignore: cast_nullable_to_non_nullable
as String,fullName: null == fullName ? _self.fullName : fullName // ignore: cast_nullable_to_non_nullable
as String,phoneNumber: null == phoneNumber ? _self.phoneNumber : phoneNumber // ignore: cast_nullable_to_non_nullable
as String,
  ));
}

}


/// Adds pattern-matching-related methods to [SignupRequestDto].
extension SignupRequestDtoPatterns on SignupRequestDto {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _SignupRequestDto value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _SignupRequestDto() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _SignupRequestDto value)  $default,){
final _that = this;
switch (_that) {
case _SignupRequestDto():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _SignupRequestDto value)?  $default,){
final _that = this;
switch (_that) {
case _SignupRequestDto() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String email,  String password,  String fullName,  String phoneNumber)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _SignupRequestDto() when $default != null:
return $default(_that.email,_that.password,_that.fullName,_that.phoneNumber);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String email,  String password,  String fullName,  String phoneNumber)  $default,) {final _that = this;
switch (_that) {
case _SignupRequestDto():
return $default(_that.email,_that.password,_that.fullName,_that.phoneNumber);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String email,  String password,  String fullName,  String phoneNumber)?  $default,) {final _that = this;
switch (_that) {
case _SignupRequestDto() when $default != null:
return $default(_that.email,_that.password,_that.fullName,_that.phoneNumber);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _SignupRequestDto implements SignupRequestDto {
  const _SignupRequestDto({required this.email, required this.password, required this.fullName, required this.phoneNumber});
  factory _SignupRequestDto.fromJson(Map<String, dynamic> json) => _$SignupRequestDtoFromJson(json);

@override final  String email;
@override final  String password;
@override final  String fullName;
@override final  String phoneNumber;

/// Create a copy of SignupRequestDto
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$SignupRequestDtoCopyWith<_SignupRequestDto> get copyWith => __$SignupRequestDtoCopyWithImpl<_SignupRequestDto>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$SignupRequestDtoToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _SignupRequestDto&&(identical(other.email, email) || other.email == email)&&(identical(other.password, password) || other.password == password)&&(identical(other.fullName, fullName) || other.fullName == fullName)&&(identical(other.phoneNumber, phoneNumber) || other.phoneNumber == phoneNumber));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,email,password,fullName,phoneNumber);

@override
String toString() {
  return 'SignupRequestDto(email: $email, password: $password, fullName: $fullName, phoneNumber: $phoneNumber)';
}


}

/// @nodoc
abstract mixin class _$SignupRequestDtoCopyWith<$Res> implements $SignupRequestDtoCopyWith<$Res> {
  factory _$SignupRequestDtoCopyWith(_SignupRequestDto value, $Res Function(_SignupRequestDto) _then) = __$SignupRequestDtoCopyWithImpl;
@override @useResult
$Res call({
 String email, String password, String fullName, String phoneNumber
});




}
/// @nodoc
class __$SignupRequestDtoCopyWithImpl<$Res>
    implements _$SignupRequestDtoCopyWith<$Res> {
  __$SignupRequestDtoCopyWithImpl(this._self, this._then);

  final _SignupRequestDto _self;
  final $Res Function(_SignupRequestDto) _then;

/// Create a copy of SignupRequestDto
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? email = null,Object? password = null,Object? fullName = null,Object? phoneNumber = null,}) {
  return _then(_SignupRequestDto(
email: null == email ? _self.email : email // ignore: cast_nullable_to_non_nullable
as String,password: null == password ? _self.password : password // ignore: cast_nullable_to_non_nullable
as String,fullName: null == fullName ? _self.fullName : fullName // ignore: cast_nullable_to_non_nullable
as String,phoneNumber: null == phoneNumber ? _self.phoneNumber : phoneNumber // ignore: cast_nullable_to_non_nullable
as String,
  ));
}


}

// dart format on
