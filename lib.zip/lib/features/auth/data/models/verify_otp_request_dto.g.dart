// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'verify_otp_request_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_VerifyOtpRequestDto _$VerifyOtpRequestDtoFromJson(Map<String, dynamic> json) =>
    _VerifyOtpRequestDto(
      email: json['email'] as String?,
      phone: json['phone'] as String?,
      code: json['code'] as String,
    );

Map<String, dynamic> _$VerifyOtpRequestDtoToJson(
  _VerifyOtpRequestDto instance,
) => <String, dynamic>{
  'email': instance.email,
  'phone': instance.phone,
  'code': instance.code,
};
