// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'signup_request_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_SignupRequestDto _$SignupRequestDtoFromJson(Map<String, dynamic> json) =>
    _SignupRequestDto(
      email: json['email'] as String,
      password: json['password'] as String,
      fullName: json['fullName'] as String,
      phoneNumber: json['phoneNumber'] as String,
    );

Map<String, dynamic> _$SignupRequestDtoToJson(_SignupRequestDto instance) =>
    <String, dynamic>{
      'email': instance.email,
      'password': instance.password,
      'fullName': instance.fullName,
      'phoneNumber': instance.phoneNumber,
    };
