// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'send_otp_request_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_SendOtpRequestDto _$SendOtpRequestDtoFromJson(Map<String, dynamic> json) =>
    _SendOtpRequestDto(
      email: json['email'] as String?,
      phone: json['phone'] as String?,
    );

Map<String, dynamic> _$SendOtpRequestDtoToJson(_SendOtpRequestDto instance) =>
    <String, dynamic>{'email': instance.email, 'phone': instance.phone};
