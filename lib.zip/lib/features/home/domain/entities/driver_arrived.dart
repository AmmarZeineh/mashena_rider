class DriverArrived {
  final int tripId;
  final String? arrivedAt;
  final int freeWaitTimeSeconds;

  const DriverArrived({
    required this.tripId,
    this.arrivedAt,
    this.freeWaitTimeSeconds = 300,
  });
}
