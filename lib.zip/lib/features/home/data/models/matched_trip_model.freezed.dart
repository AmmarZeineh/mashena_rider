// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'matched_trip_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$MatchedTripModel {

 int get tripId; String get tripStatus; int get rideRequestId; double get pickupLat; double get pickupLng; double get destinationLat; double get destinationLng; String? get matchedAt; int get driverId; String? get driverFullName; String? get driverFirstName; String? get driverLastName; String? get driverProfileImage; double get driverRatingAvg; int? get vehicleId; String? get plateNumber; String? get color; String? get manufacturer; String? get model; int? get vehicleTypeId; List<RideLocationModel> get stops;
/// Create a copy of MatchedTripModel
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$MatchedTripModelCopyWith<MatchedTripModel> get copyWith => _$MatchedTripModelCopyWithImpl<MatchedTripModel>(this as MatchedTripModel, _$identity);

  /// Serializes this MatchedTripModel to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is MatchedTripModel&&(identical(other.tripId, tripId) || other.tripId == tripId)&&(identical(other.tripStatus, tripStatus) || other.tripStatus == tripStatus)&&(identical(other.rideRequestId, rideRequestId) || other.rideRequestId == rideRequestId)&&(identical(other.pickupLat, pickupLat) || other.pickupLat == pickupLat)&&(identical(other.pickupLng, pickupLng) || other.pickupLng == pickupLng)&&(identical(other.destinationLat, destinationLat) || other.destinationLat == destinationLat)&&(identical(other.destinationLng, destinationLng) || other.destinationLng == destinationLng)&&(identical(other.matchedAt, matchedAt) || other.matchedAt == matchedAt)&&(identical(other.driverId, driverId) || other.driverId == driverId)&&(identical(other.driverFullName, driverFullName) || other.driverFullName == driverFullName)&&(identical(other.driverFirstName, driverFirstName) || other.driverFirstName == driverFirstName)&&(identical(other.driverLastName, driverLastName) || other.driverLastName == driverLastName)&&(identical(other.driverProfileImage, driverProfileImage) || other.driverProfileImage == driverProfileImage)&&(identical(other.driverRatingAvg, driverRatingAvg) || other.driverRatingAvg == driverRatingAvg)&&(identical(other.vehicleId, vehicleId) || other.vehicleId == vehicleId)&&(identical(other.plateNumber, plateNumber) || other.plateNumber == plateNumber)&&(identical(other.color, color) || other.color == color)&&(identical(other.manufacturer, manufacturer) || other.manufacturer == manufacturer)&&(identical(other.model, model) || other.model == model)&&(identical(other.vehicleTypeId, vehicleTypeId) || other.vehicleTypeId == vehicleTypeId)&&const DeepCollectionEquality().equals(other.stops, stops));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hashAll([runtimeType,tripId,tripStatus,rideRequestId,pickupLat,pickupLng,destinationLat,destinationLng,matchedAt,driverId,driverFullName,driverFirstName,driverLastName,driverProfileImage,driverRatingAvg,vehicleId,plateNumber,color,manufacturer,model,vehicleTypeId,const DeepCollectionEquality().hash(stops)]);

@override
String toString() {
  return 'MatchedTripModel(tripId: $tripId, tripStatus: $tripStatus, rideRequestId: $rideRequestId, pickupLat: $pickupLat, pickupLng: $pickupLng, destinationLat: $destinationLat, destinationLng: $destinationLng, matchedAt: $matchedAt, driverId: $driverId, driverFullName: $driverFullName, driverFirstName: $driverFirstName, driverLastName: $driverLastName, driverProfileImage: $driverProfileImage, driverRatingAvg: $driverRatingAvg, vehicleId: $vehicleId, plateNumber: $plateNumber, color: $color, manufacturer: $manufacturer, model: $model, vehicleTypeId: $vehicleTypeId, stops: $stops)';
}


}

/// @nodoc
abstract mixin class $MatchedTripModelCopyWith<$Res>  {
  factory $MatchedTripModelCopyWith(MatchedTripModel value, $Res Function(MatchedTripModel) _then) = _$MatchedTripModelCopyWithImpl;
@useResult
$Res call({
 int tripId, String tripStatus, int rideRequestId, double pickupLat, double pickupLng, double destinationLat, double destinationLng, String? matchedAt, int driverId, String? driverFullName, String? driverFirstName, String? driverLastName, String? driverProfileImage, double driverRatingAvg, int? vehicleId, String? plateNumber, String? color, String? manufacturer, String? model, int? vehicleTypeId, List<RideLocationModel> stops
});




}
/// @nodoc
class _$MatchedTripModelCopyWithImpl<$Res>
    implements $MatchedTripModelCopyWith<$Res> {
  _$MatchedTripModelCopyWithImpl(this._self, this._then);

  final MatchedTripModel _self;
  final $Res Function(MatchedTripModel) _then;

/// Create a copy of MatchedTripModel
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? tripId = null,Object? tripStatus = null,Object? rideRequestId = null,Object? pickupLat = null,Object? pickupLng = null,Object? destinationLat = null,Object? destinationLng = null,Object? matchedAt = freezed,Object? driverId = null,Object? driverFullName = freezed,Object? driverFirstName = freezed,Object? driverLastName = freezed,Object? driverProfileImage = freezed,Object? driverRatingAvg = null,Object? vehicleId = freezed,Object? plateNumber = freezed,Object? color = freezed,Object? manufacturer = freezed,Object? model = freezed,Object? vehicleTypeId = freezed,Object? stops = null,}) {
  return _then(_self.copyWith(
tripId: null == tripId ? _self.tripId : tripId // ignore: cast_nullable_to_non_nullable
as int,tripStatus: null == tripStatus ? _self.tripStatus : tripStatus // ignore: cast_nullable_to_non_nullable
as String,rideRequestId: null == rideRequestId ? _self.rideRequestId : rideRequestId // ignore: cast_nullable_to_non_nullable
as int,pickupLat: null == pickupLat ? _self.pickupLat : pickupLat // ignore: cast_nullable_to_non_nullable
as double,pickupLng: null == pickupLng ? _self.pickupLng : pickupLng // ignore: cast_nullable_to_non_nullable
as double,destinationLat: null == destinationLat ? _self.destinationLat : destinationLat // ignore: cast_nullable_to_non_nullable
as double,destinationLng: null == destinationLng ? _self.destinationLng : destinationLng // ignore: cast_nullable_to_non_nullable
as double,matchedAt: freezed == matchedAt ? _self.matchedAt : matchedAt // ignore: cast_nullable_to_non_nullable
as String?,driverId: null == driverId ? _self.driverId : driverId // ignore: cast_nullable_to_non_nullable
as int,driverFullName: freezed == driverFullName ? _self.driverFullName : driverFullName // ignore: cast_nullable_to_non_nullable
as String?,driverFirstName: freezed == driverFirstName ? _self.driverFirstName : driverFirstName // ignore: cast_nullable_to_non_nullable
as String?,driverLastName: freezed == driverLastName ? _self.driverLastName : driverLastName // ignore: cast_nullable_to_non_nullable
as String?,driverProfileImage: freezed == driverProfileImage ? _self.driverProfileImage : driverProfileImage // ignore: cast_nullable_to_non_nullable
as String?,driverRatingAvg: null == driverRatingAvg ? _self.driverRatingAvg : driverRatingAvg // ignore: cast_nullable_to_non_nullable
as double,vehicleId: freezed == vehicleId ? _self.vehicleId : vehicleId // ignore: cast_nullable_to_non_nullable
as int?,plateNumber: freezed == plateNumber ? _self.plateNumber : plateNumber // ignore: cast_nullable_to_non_nullable
as String?,color: freezed == color ? _self.color : color // ignore: cast_nullable_to_non_nullable
as String?,manufacturer: freezed == manufacturer ? _self.manufacturer : manufacturer // ignore: cast_nullable_to_non_nullable
as String?,model: freezed == model ? _self.model : model // ignore: cast_nullable_to_non_nullable
as String?,vehicleTypeId: freezed == vehicleTypeId ? _self.vehicleTypeId : vehicleTypeId // ignore: cast_nullable_to_non_nullable
as int?,stops: null == stops ? _self.stops : stops // ignore: cast_nullable_to_non_nullable
as List<RideLocationModel>,
  ));
}

}


/// Adds pattern-matching-related methods to [MatchedTripModel].
extension MatchedTripModelPatterns on MatchedTripModel {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _MatchedTripModel value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _MatchedTripModel() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _MatchedTripModel value)  $default,){
final _that = this;
switch (_that) {
case _MatchedTripModel():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _MatchedTripModel value)?  $default,){
final _that = this;
switch (_that) {
case _MatchedTripModel() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( int tripId,  String tripStatus,  int rideRequestId,  double pickupLat,  double pickupLng,  double destinationLat,  double destinationLng,  String? matchedAt,  int driverId,  String? driverFullName,  String? driverFirstName,  String? driverLastName,  String? driverProfileImage,  double driverRatingAvg,  int? vehicleId,  String? plateNumber,  String? color,  String? manufacturer,  String? model,  int? vehicleTypeId,  List<RideLocationModel> stops)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _MatchedTripModel() when $default != null:
return $default(_that.tripId,_that.tripStatus,_that.rideRequestId,_that.pickupLat,_that.pickupLng,_that.destinationLat,_that.destinationLng,_that.matchedAt,_that.driverId,_that.driverFullName,_that.driverFirstName,_that.driverLastName,_that.driverProfileImage,_that.driverRatingAvg,_that.vehicleId,_that.plateNumber,_that.color,_that.manufacturer,_that.model,_that.vehicleTypeId,_that.stops);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( int tripId,  String tripStatus,  int rideRequestId,  double pickupLat,  double pickupLng,  double destinationLat,  double destinationLng,  String? matchedAt,  int driverId,  String? driverFullName,  String? driverFirstName,  String? driverLastName,  String? driverProfileImage,  double driverRatingAvg,  int? vehicleId,  String? plateNumber,  String? color,  String? manufacturer,  String? model,  int? vehicleTypeId,  List<RideLocationModel> stops)  $default,) {final _that = this;
switch (_that) {
case _MatchedTripModel():
return $default(_that.tripId,_that.tripStatus,_that.rideRequestId,_that.pickupLat,_that.pickupLng,_that.destinationLat,_that.destinationLng,_that.matchedAt,_that.driverId,_that.driverFullName,_that.driverFirstName,_that.driverLastName,_that.driverProfileImage,_that.driverRatingAvg,_that.vehicleId,_that.plateNumber,_that.color,_that.manufacturer,_that.model,_that.vehicleTypeId,_that.stops);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( int tripId,  String tripStatus,  int rideRequestId,  double pickupLat,  double pickupLng,  double destinationLat,  double destinationLng,  String? matchedAt,  int driverId,  String? driverFullName,  String? driverFirstName,  String? driverLastName,  String? driverProfileImage,  double driverRatingAvg,  int? vehicleId,  String? plateNumber,  String? color,  String? manufacturer,  String? model,  int? vehicleTypeId,  List<RideLocationModel> stops)?  $default,) {final _that = this;
switch (_that) {
case _MatchedTripModel() when $default != null:
return $default(_that.tripId,_that.tripStatus,_that.rideRequestId,_that.pickupLat,_that.pickupLng,_that.destinationLat,_that.destinationLng,_that.matchedAt,_that.driverId,_that.driverFullName,_that.driverFirstName,_that.driverLastName,_that.driverProfileImage,_that.driverRatingAvg,_that.vehicleId,_that.plateNumber,_that.color,_that.manufacturer,_that.model,_that.vehicleTypeId,_that.stops);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _MatchedTripModel extends MatchedTripModel {
  const _MatchedTripModel({required this.tripId, required this.tripStatus, required this.rideRequestId, required this.pickupLat, required this.pickupLng, required this.destinationLat, required this.destinationLng, this.matchedAt, required this.driverId, this.driverFullName, this.driverFirstName, this.driverLastName, this.driverProfileImage, required this.driverRatingAvg, this.vehicleId, this.plateNumber, this.color, this.manufacturer, this.model, this.vehicleTypeId, final  List<RideLocationModel> stops = const []}): _stops = stops,super._();
  factory _MatchedTripModel.fromJson(Map<String, dynamic> json) => _$MatchedTripModelFromJson(json);

@override final  int tripId;
@override final  String tripStatus;
@override final  int rideRequestId;
@override final  double pickupLat;
@override final  double pickupLng;
@override final  double destinationLat;
@override final  double destinationLng;
@override final  String? matchedAt;
@override final  int driverId;
@override final  String? driverFullName;
@override final  String? driverFirstName;
@override final  String? driverLastName;
@override final  String? driverProfileImage;
@override final  double driverRatingAvg;
@override final  int? vehicleId;
@override final  String? plateNumber;
@override final  String? color;
@override final  String? manufacturer;
@override final  String? model;
@override final  int? vehicleTypeId;
 final  List<RideLocationModel> _stops;
@override@JsonKey() List<RideLocationModel> get stops {
  if (_stops is EqualUnmodifiableListView) return _stops;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_stops);
}


/// Create a copy of MatchedTripModel
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$MatchedTripModelCopyWith<_MatchedTripModel> get copyWith => __$MatchedTripModelCopyWithImpl<_MatchedTripModel>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$MatchedTripModelToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _MatchedTripModel&&(identical(other.tripId, tripId) || other.tripId == tripId)&&(identical(other.tripStatus, tripStatus) || other.tripStatus == tripStatus)&&(identical(other.rideRequestId, rideRequestId) || other.rideRequestId == rideRequestId)&&(identical(other.pickupLat, pickupLat) || other.pickupLat == pickupLat)&&(identical(other.pickupLng, pickupLng) || other.pickupLng == pickupLng)&&(identical(other.destinationLat, destinationLat) || other.destinationLat == destinationLat)&&(identical(other.destinationLng, destinationLng) || other.destinationLng == destinationLng)&&(identical(other.matchedAt, matchedAt) || other.matchedAt == matchedAt)&&(identical(other.driverId, driverId) || other.driverId == driverId)&&(identical(other.driverFullName, driverFullName) || other.driverFullName == driverFullName)&&(identical(other.driverFirstName, driverFirstName) || other.driverFirstName == driverFirstName)&&(identical(other.driverLastName, driverLastName) || other.driverLastName == driverLastName)&&(identical(other.driverProfileImage, driverProfileImage) || other.driverProfileImage == driverProfileImage)&&(identical(other.driverRatingAvg, driverRatingAvg) || other.driverRatingAvg == driverRatingAvg)&&(identical(other.vehicleId, vehicleId) || other.vehicleId == vehicleId)&&(identical(other.plateNumber, plateNumber) || other.plateNumber == plateNumber)&&(identical(other.color, color) || other.color == color)&&(identical(other.manufacturer, manufacturer) || other.manufacturer == manufacturer)&&(identical(other.model, model) || other.model == model)&&(identical(other.vehicleTypeId, vehicleTypeId) || other.vehicleTypeId == vehicleTypeId)&&const DeepCollectionEquality().equals(other._stops, _stops));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hashAll([runtimeType,tripId,tripStatus,rideRequestId,pickupLat,pickupLng,destinationLat,destinationLng,matchedAt,driverId,driverFullName,driverFirstName,driverLastName,driverProfileImage,driverRatingAvg,vehicleId,plateNumber,color,manufacturer,model,vehicleTypeId,const DeepCollectionEquality().hash(_stops)]);

@override
String toString() {
  return 'MatchedTripModel(tripId: $tripId, tripStatus: $tripStatus, rideRequestId: $rideRequestId, pickupLat: $pickupLat, pickupLng: $pickupLng, destinationLat: $destinationLat, destinationLng: $destinationLng, matchedAt: $matchedAt, driverId: $driverId, driverFullName: $driverFullName, driverFirstName: $driverFirstName, driverLastName: $driverLastName, driverProfileImage: $driverProfileImage, driverRatingAvg: $driverRatingAvg, vehicleId: $vehicleId, plateNumber: $plateNumber, color: $color, manufacturer: $manufacturer, model: $model, vehicleTypeId: $vehicleTypeId, stops: $stops)';
}


}

/// @nodoc
abstract mixin class _$MatchedTripModelCopyWith<$Res> implements $MatchedTripModelCopyWith<$Res> {
  factory _$MatchedTripModelCopyWith(_MatchedTripModel value, $Res Function(_MatchedTripModel) _then) = __$MatchedTripModelCopyWithImpl;
@override @useResult
$Res call({
 int tripId, String tripStatus, int rideRequestId, double pickupLat, double pickupLng, double destinationLat, double destinationLng, String? matchedAt, int driverId, String? driverFullName, String? driverFirstName, String? driverLastName, String? driverProfileImage, double driverRatingAvg, int? vehicleId, String? plateNumber, String? color, String? manufacturer, String? model, int? vehicleTypeId, List<RideLocationModel> stops
});




}
/// @nodoc
class __$MatchedTripModelCopyWithImpl<$Res>
    implements _$MatchedTripModelCopyWith<$Res> {
  __$MatchedTripModelCopyWithImpl(this._self, this._then);

  final _MatchedTripModel _self;
  final $Res Function(_MatchedTripModel) _then;

/// Create a copy of MatchedTripModel
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? tripId = null,Object? tripStatus = null,Object? rideRequestId = null,Object? pickupLat = null,Object? pickupLng = null,Object? destinationLat = null,Object? destinationLng = null,Object? matchedAt = freezed,Object? driverId = null,Object? driverFullName = freezed,Object? driverFirstName = freezed,Object? driverLastName = freezed,Object? driverProfileImage = freezed,Object? driverRatingAvg = null,Object? vehicleId = freezed,Object? plateNumber = freezed,Object? color = freezed,Object? manufacturer = freezed,Object? model = freezed,Object? vehicleTypeId = freezed,Object? stops = null,}) {
  return _then(_MatchedTripModel(
tripId: null == tripId ? _self.tripId : tripId // ignore: cast_nullable_to_non_nullable
as int,tripStatus: null == tripStatus ? _self.tripStatus : tripStatus // ignore: cast_nullable_to_non_nullable
as String,rideRequestId: null == rideRequestId ? _self.rideRequestId : rideRequestId // ignore: cast_nullable_to_non_nullable
as int,pickupLat: null == pickupLat ? _self.pickupLat : pickupLat // ignore: cast_nullable_to_non_nullable
as double,pickupLng: null == pickupLng ? _self.pickupLng : pickupLng // ignore: cast_nullable_to_non_nullable
as double,destinationLat: null == destinationLat ? _self.destinationLat : destinationLat // ignore: cast_nullable_to_non_nullable
as double,destinationLng: null == destinationLng ? _self.destinationLng : destinationLng // ignore: cast_nullable_to_non_nullable
as double,matchedAt: freezed == matchedAt ? _self.matchedAt : matchedAt // ignore: cast_nullable_to_non_nullable
as String?,driverId: null == driverId ? _self.driverId : driverId // ignore: cast_nullable_to_non_nullable
as int,driverFullName: freezed == driverFullName ? _self.driverFullName : driverFullName // ignore: cast_nullable_to_non_nullable
as String?,driverFirstName: freezed == driverFirstName ? _self.driverFirstName : driverFirstName // ignore: cast_nullable_to_non_nullable
as String?,driverLastName: freezed == driverLastName ? _self.driverLastName : driverLastName // ignore: cast_nullable_to_non_nullable
as String?,driverProfileImage: freezed == driverProfileImage ? _self.driverProfileImage : driverProfileImage // ignore: cast_nullable_to_non_nullable
as String?,driverRatingAvg: null == driverRatingAvg ? _self.driverRatingAvg : driverRatingAvg // ignore: cast_nullable_to_non_nullable
as double,vehicleId: freezed == vehicleId ? _self.vehicleId : vehicleId // ignore: cast_nullable_to_non_nullable
as int?,plateNumber: freezed == plateNumber ? _self.plateNumber : plateNumber // ignore: cast_nullable_to_non_nullable
as String?,color: freezed == color ? _self.color : color // ignore: cast_nullable_to_non_nullable
as String?,manufacturer: freezed == manufacturer ? _self.manufacturer : manufacturer // ignore: cast_nullable_to_non_nullable
as String?,model: freezed == model ? _self.model : model // ignore: cast_nullable_to_non_nullable
as String?,vehicleTypeId: freezed == vehicleTypeId ? _self.vehicleTypeId : vehicleTypeId // ignore: cast_nullable_to_non_nullable
as int?,stops: null == stops ? _self._stops : stops // ignore: cast_nullable_to_non_nullable
as List<RideLocationModel>,
  ));
}


}

// dart format on
