// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'ride_location_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$RideLocationModel {

 double get lat; double get lng; String get address;
/// Create a copy of RideLocationModel
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$RideLocationModelCopyWith<RideLocationModel> get copyWith => _$RideLocationModelCopyWithImpl<RideLocationModel>(this as RideLocationModel, _$identity);

  /// Serializes this RideLocationModel to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is RideLocationModel&&(identical(other.lat, lat) || other.lat == lat)&&(identical(other.lng, lng) || other.lng == lng)&&(identical(other.address, address) || other.address == address));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,lat,lng,address);

@override
String toString() {
  return 'RideLocationModel(lat: $lat, lng: $lng, address: $address)';
}


}

/// @nodoc
abstract mixin class $RideLocationModelCopyWith<$Res>  {
  factory $RideLocationModelCopyWith(RideLocationModel value, $Res Function(RideLocationModel) _then) = _$RideLocationModelCopyWithImpl;
@useResult
$Res call({
 double lat, double lng, String address
});




}
/// @nodoc
class _$RideLocationModelCopyWithImpl<$Res>
    implements $RideLocationModelCopyWith<$Res> {
  _$RideLocationModelCopyWithImpl(this._self, this._then);

  final RideLocationModel _self;
  final $Res Function(RideLocationModel) _then;

/// Create a copy of RideLocationModel
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? lat = null,Object? lng = null,Object? address = null,}) {
  return _then(_self.copyWith(
lat: null == lat ? _self.lat : lat // ignore: cast_nullable_to_non_nullable
as double,lng: null == lng ? _self.lng : lng // ignore: cast_nullable_to_non_nullable
as double,address: null == address ? _self.address : address // ignore: cast_nullable_to_non_nullable
as String,
  ));
}

}


/// Adds pattern-matching-related methods to [RideLocationModel].
extension RideLocationModelPatterns on RideLocationModel {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _RideLocationModel value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _RideLocationModel() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _RideLocationModel value)  $default,){
final _that = this;
switch (_that) {
case _RideLocationModel():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _RideLocationModel value)?  $default,){
final _that = this;
switch (_that) {
case _RideLocationModel() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( double lat,  double lng,  String address)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _RideLocationModel() when $default != null:
return $default(_that.lat,_that.lng,_that.address);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( double lat,  double lng,  String address)  $default,) {final _that = this;
switch (_that) {
case _RideLocationModel():
return $default(_that.lat,_that.lng,_that.address);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( double lat,  double lng,  String address)?  $default,) {final _that = this;
switch (_that) {
case _RideLocationModel() when $default != null:
return $default(_that.lat,_that.lng,_that.address);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _RideLocationModel extends RideLocationModel {
  const _RideLocationModel({required this.lat, required this.lng, required this.address}): super._();
  factory _RideLocationModel.fromJson(Map<String, dynamic> json) => _$RideLocationModelFromJson(json);

@override final  double lat;
@override final  double lng;
@override final  String address;

/// Create a copy of RideLocationModel
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$RideLocationModelCopyWith<_RideLocationModel> get copyWith => __$RideLocationModelCopyWithImpl<_RideLocationModel>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$RideLocationModelToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _RideLocationModel&&(identical(other.lat, lat) || other.lat == lat)&&(identical(other.lng, lng) || other.lng == lng)&&(identical(other.address, address) || other.address == address));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,lat,lng,address);

@override
String toString() {
  return 'RideLocationModel(lat: $lat, lng: $lng, address: $address)';
}


}

/// @nodoc
abstract mixin class _$RideLocationModelCopyWith<$Res> implements $RideLocationModelCopyWith<$Res> {
  factory _$RideLocationModelCopyWith(_RideLocationModel value, $Res Function(_RideLocationModel) _then) = __$RideLocationModelCopyWithImpl;
@override @useResult
$Res call({
 double lat, double lng, String address
});




}
/// @nodoc
class __$RideLocationModelCopyWithImpl<$Res>
    implements _$RideLocationModelCopyWith<$Res> {
  __$RideLocationModelCopyWithImpl(this._self, this._then);

  final _RideLocationModel _self;
  final $Res Function(_RideLocationModel) _then;

/// Create a copy of RideLocationModel
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? lat = null,Object? lng = null,Object? address = null,}) {
  return _then(_RideLocationModel(
lat: null == lat ? _self.lat : lat // ignore: cast_nullable_to_non_nullable
as double,lng: null == lng ? _self.lng : lng // ignore: cast_nullable_to_non_nullable
as double,address: null == address ? _self.address : address // ignore: cast_nullable_to_non_nullable
as String,
  ));
}


}

// dart format on
