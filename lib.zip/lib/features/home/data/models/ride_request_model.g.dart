// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ride_request_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_RideRequestModel _$RideRequestModelFromJson(
  Map<String, dynamic> json,
) => _RideRequestModel(
  pickup: RideLocationModel.fromJson(json['pickup'] as Map<String, dynamic>),
  destination: RideLocationModel.fromJson(
    json['destination'] as Map<String, dynamic>,
  ),
  stops:
      (json['stops'] as List<dynamic>?)
          ?.map((e) => RideLocationModel.fromJson(e as Map<String, dynamic>))
          .toList() ??
      const [],
);

Map<String, dynamic> _$RideRequestModelToJson(_RideRequestModel instance) =>
    <String, dynamic>{
      'pickup': instance.pickup,
      'destination': instance.destination,
      'stops': instance.stops,
    };
