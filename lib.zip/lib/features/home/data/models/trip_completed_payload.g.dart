// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'trip_completed_payload.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_TripCompletedPayload _$TripCompletedPayloadFromJson(
  Map<String, dynamic> json,
) => _TripCompletedPayload(
  tripId: (json['tripId'] as num).toInt(),
  completedAt: json['completedAt'] as String?,
  distanceKm: json['distanceKm'] as num?,
  durationSec: json['durationSec'] as num?,
);

Map<String, dynamic> _$TripCompletedPayloadToJson(
  _TripCompletedPayload instance,
) => <String, dynamic>{
  'tripId': instance.tripId,
  'completedAt': instance.completedAt,
  'distanceKm': instance.distanceKm,
  'durationSec': instance.durationSec,
};
