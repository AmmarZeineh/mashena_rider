// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'trip_completed_payload.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$TripCompletedPayload {

 int get tripId; String? get completedAt; num? get distanceKm; num? get durationSec;
/// Create a copy of TripCompletedPayload
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$TripCompletedPayloadCopyWith<TripCompletedPayload> get copyWith => _$TripCompletedPayloadCopyWithImpl<TripCompletedPayload>(this as TripCompletedPayload, _$identity);

  /// Serializes this TripCompletedPayload to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is TripCompletedPayload&&(identical(other.tripId, tripId) || other.tripId == tripId)&&(identical(other.completedAt, completedAt) || other.completedAt == completedAt)&&(identical(other.distanceKm, distanceKm) || other.distanceKm == distanceKm)&&(identical(other.durationSec, durationSec) || other.durationSec == durationSec));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,tripId,completedAt,distanceKm,durationSec);

@override
String toString() {
  return 'TripCompletedPayload(tripId: $tripId, completedAt: $completedAt, distanceKm: $distanceKm, durationSec: $durationSec)';
}


}

/// @nodoc
abstract mixin class $TripCompletedPayloadCopyWith<$Res>  {
  factory $TripCompletedPayloadCopyWith(TripCompletedPayload value, $Res Function(TripCompletedPayload) _then) = _$TripCompletedPayloadCopyWithImpl;
@useResult
$Res call({
 int tripId, String? completedAt, num? distanceKm, num? durationSec
});




}
/// @nodoc
class _$TripCompletedPayloadCopyWithImpl<$Res>
    implements $TripCompletedPayloadCopyWith<$Res> {
  _$TripCompletedPayloadCopyWithImpl(this._self, this._then);

  final TripCompletedPayload _self;
  final $Res Function(TripCompletedPayload) _then;

/// Create a copy of TripCompletedPayload
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? tripId = null,Object? completedAt = freezed,Object? distanceKm = freezed,Object? durationSec = freezed,}) {
  return _then(_self.copyWith(
tripId: null == tripId ? _self.tripId : tripId // ignore: cast_nullable_to_non_nullable
as int,completedAt: freezed == completedAt ? _self.completedAt : completedAt // ignore: cast_nullable_to_non_nullable
as String?,distanceKm: freezed == distanceKm ? _self.distanceKm : distanceKm // ignore: cast_nullable_to_non_nullable
as num?,durationSec: freezed == durationSec ? _self.durationSec : durationSec // ignore: cast_nullable_to_non_nullable
as num?,
  ));
}

}


/// Adds pattern-matching-related methods to [TripCompletedPayload].
extension TripCompletedPayloadPatterns on TripCompletedPayload {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _TripCompletedPayload value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _TripCompletedPayload() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _TripCompletedPayload value)  $default,){
final _that = this;
switch (_that) {
case _TripCompletedPayload():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _TripCompletedPayload value)?  $default,){
final _that = this;
switch (_that) {
case _TripCompletedPayload() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( int tripId,  String? completedAt,  num? distanceKm,  num? durationSec)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _TripCompletedPayload() when $default != null:
return $default(_that.tripId,_that.completedAt,_that.distanceKm,_that.durationSec);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( int tripId,  String? completedAt,  num? distanceKm,  num? durationSec)  $default,) {final _that = this;
switch (_that) {
case _TripCompletedPayload():
return $default(_that.tripId,_that.completedAt,_that.distanceKm,_that.durationSec);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( int tripId,  String? completedAt,  num? distanceKm,  num? durationSec)?  $default,) {final _that = this;
switch (_that) {
case _TripCompletedPayload() when $default != null:
return $default(_that.tripId,_that.completedAt,_that.distanceKm,_that.durationSec);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _TripCompletedPayload extends TripCompletedPayload {
  const _TripCompletedPayload({required this.tripId, this.completedAt, this.distanceKm, this.durationSec}): super._();
  factory _TripCompletedPayload.fromJson(Map<String, dynamic> json) => _$TripCompletedPayloadFromJson(json);

@override final  int tripId;
@override final  String? completedAt;
@override final  num? distanceKm;
@override final  num? durationSec;

/// Create a copy of TripCompletedPayload
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$TripCompletedPayloadCopyWith<_TripCompletedPayload> get copyWith => __$TripCompletedPayloadCopyWithImpl<_TripCompletedPayload>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$TripCompletedPayloadToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _TripCompletedPayload&&(identical(other.tripId, tripId) || other.tripId == tripId)&&(identical(other.completedAt, completedAt) || other.completedAt == completedAt)&&(identical(other.distanceKm, distanceKm) || other.distanceKm == distanceKm)&&(identical(other.durationSec, durationSec) || other.durationSec == durationSec));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,tripId,completedAt,distanceKm,durationSec);

@override
String toString() {
  return 'TripCompletedPayload(tripId: $tripId, completedAt: $completedAt, distanceKm: $distanceKm, durationSec: $durationSec)';
}


}

/// @nodoc
abstract mixin class _$TripCompletedPayloadCopyWith<$Res> implements $TripCompletedPayloadCopyWith<$Res> {
  factory _$TripCompletedPayloadCopyWith(_TripCompletedPayload value, $Res Function(_TripCompletedPayload) _then) = __$TripCompletedPayloadCopyWithImpl;
@override @useResult
$Res call({
 int tripId, String? completedAt, num? distanceKm, num? durationSec
});




}
/// @nodoc
class __$TripCompletedPayloadCopyWithImpl<$Res>
    implements _$TripCompletedPayloadCopyWith<$Res> {
  __$TripCompletedPayloadCopyWithImpl(this._self, this._then);

  final _TripCompletedPayload _self;
  final $Res Function(_TripCompletedPayload) _then;

/// Create a copy of TripCompletedPayload
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? tripId = null,Object? completedAt = freezed,Object? distanceKm = freezed,Object? durationSec = freezed,}) {
  return _then(_TripCompletedPayload(
tripId: null == tripId ? _self.tripId : tripId // ignore: cast_nullable_to_non_nullable
as int,completedAt: freezed == completedAt ? _self.completedAt : completedAt // ignore: cast_nullable_to_non_nullable
as String?,distanceKm: freezed == distanceKm ? _self.distanceKm : distanceKm // ignore: cast_nullable_to_non_nullable
as num?,durationSec: freezed == durationSec ? _self.durationSec : durationSec // ignore: cast_nullable_to_non_nullable
as num?,
  ));
}


}

// dart format on
