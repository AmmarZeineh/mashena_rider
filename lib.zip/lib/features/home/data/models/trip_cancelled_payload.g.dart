// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'trip_cancelled_payload.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_TripCancelledPayload _$TripCancelledPayloadFromJson(
  Map<String, dynamic> json,
) => _TripCancelledPayload(
  tripId: (json['tripId'] as num).toInt(),
  canceledAt: json['canceledAt'] as String?,
  cancelledBy: json['cancelledBy'] as String?,
);

Map<String, dynamic> _$TripCancelledPayloadToJson(
  _TripCancelledPayload instance,
) => <String, dynamic>{
  'tripId': instance.tripId,
  'canceledAt': instance.canceledAt,
  'cancelledBy': instance.cancelledBy,
};
