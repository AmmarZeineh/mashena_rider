// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ride_location_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_RideLocationModel _$RideLocationModelFromJson(Map<String, dynamic> json) =>
    _RideLocationModel(
      lat: (json['lat'] as num).toDouble(),
      lng: (json['lng'] as num).toDouble(),
      address: json['address'] as String,
    );

Map<String, dynamic> _$RideLocationModelToJson(_RideLocationModel instance) =>
    <String, dynamic>{
      'lat': instance.lat,
      'lng': instance.lng,
      'address': instance.address,
    };
