// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'matched_trip_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_MatchedTripModel _$MatchedTripModelFromJson(Map<String, dynamic> json) =>
    _MatchedTripModel(
      tripId: (json['tripId'] as num).toInt(),
      tripStatus: json['tripStatus'] as String,
      rideRequestId: (json['rideRequestId'] as num).toInt(),
      pickupLat: (json['pickupLat'] as num).toDouble(),
      pickupLng: (json['pickupLng'] as num).toDouble(),
      destinationLat: (json['destinationLat'] as num).toDouble(),
      destinationLng: (json['destinationLng'] as num).toDouble(),
      matchedAt: json['matchedAt'] as String?,
      driverId: (json['driverId'] as num).toInt(),
      driverFullName: json['driverFullName'] as String?,
      driverFirstName: json['driverFirstName'] as String?,
      driverLastName: json['driverLastName'] as String?,
      driverProfileImage: json['driverProfileImage'] as String?,
      driverRatingAvg: (json['driverRatingAvg'] as num).toDouble(),
      vehicleId: (json['vehicleId'] as num?)?.toInt(),
      plateNumber: json['plateNumber'] as String?,
      color: json['color'] as String?,
      manufacturer: json['manufacturer'] as String?,
      model: json['model'] as String?,
      vehicleTypeId: (json['vehicleTypeId'] as num?)?.toInt(),
      stops: json['stops'] as List<dynamic>? ?? const [],
    );

Map<String, dynamic> _$MatchedTripModelToJson(_MatchedTripModel instance) =>
    <String, dynamic>{
      'tripId': instance.tripId,
      'tripStatus': instance.tripStatus,
      'rideRequestId': instance.rideRequestId,
      'pickupLat': instance.pickupLat,
      'pickupLng': instance.pickupLng,
      'destinationLat': instance.destinationLat,
      'destinationLng': instance.destinationLng,
      'matchedAt': instance.matchedAt,
      'driverId': instance.driverId,
      'driverFullName': instance.driverFullName,
      'driverFirstName': instance.driverFirstName,
      'driverLastName': instance.driverLastName,
      'driverProfileImage': instance.driverProfileImage,
      'driverRatingAvg': instance.driverRatingAvg,
      'vehicleId': instance.vehicleId,
      'plateNumber': instance.plateNumber,
      'color': instance.color,
      'manufacturer': instance.manufacturer,
      'model': instance.model,
      'vehicleTypeId': instance.vehicleTypeId,
      'stops': instance.stops,
    };
