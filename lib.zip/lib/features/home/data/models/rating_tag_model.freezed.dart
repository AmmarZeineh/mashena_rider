// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'rating_tag_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$RatingTagModel {

 int get id; String get code; String? get name; List<RatingTagLocalizationModel>? get localizations;
/// Create a copy of RatingTagModel
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$RatingTagModelCopyWith<RatingTagModel> get copyWith => _$RatingTagModelCopyWithImpl<RatingTagModel>(this as RatingTagModel, _$identity);

  /// Serializes this RatingTagModel to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is RatingTagModel&&(identical(other.id, id) || other.id == id)&&(identical(other.code, code) || other.code == code)&&(identical(other.name, name) || other.name == name)&&const DeepCollectionEquality().equals(other.localizations, localizations));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,id,code,name,const DeepCollectionEquality().hash(localizations));

@override
String toString() {
  return 'RatingTagModel(id: $id, code: $code, name: $name, localizations: $localizations)';
}


}

/// @nodoc
abstract mixin class $RatingTagModelCopyWith<$Res>  {
  factory $RatingTagModelCopyWith(RatingTagModel value, $Res Function(RatingTagModel) _then) = _$RatingTagModelCopyWithImpl;
@useResult
$Res call({
 int id, String code, String? name, List<RatingTagLocalizationModel>? localizations
});




}
/// @nodoc
class _$RatingTagModelCopyWithImpl<$Res>
    implements $RatingTagModelCopyWith<$Res> {
  _$RatingTagModelCopyWithImpl(this._self, this._then);

  final RatingTagModel _self;
  final $Res Function(RatingTagModel) _then;

/// Create a copy of RatingTagModel
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? id = null,Object? code = null,Object? name = freezed,Object? localizations = freezed,}) {
  return _then(_self.copyWith(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as int,code: null == code ? _self.code : code // ignore: cast_nullable_to_non_nullable
as String,name: freezed == name ? _self.name : name // ignore: cast_nullable_to_non_nullable
as String?,localizations: freezed == localizations ? _self.localizations : localizations // ignore: cast_nullable_to_non_nullable
as List<RatingTagLocalizationModel>?,
  ));
}

}


/// Adds pattern-matching-related methods to [RatingTagModel].
extension RatingTagModelPatterns on RatingTagModel {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _RatingTagModel value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _RatingTagModel() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _RatingTagModel value)  $default,){
final _that = this;
switch (_that) {
case _RatingTagModel():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _RatingTagModel value)?  $default,){
final _that = this;
switch (_that) {
case _RatingTagModel() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( int id,  String code,  String? name,  List<RatingTagLocalizationModel>? localizations)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _RatingTagModel() when $default != null:
return $default(_that.id,_that.code,_that.name,_that.localizations);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( int id,  String code,  String? name,  List<RatingTagLocalizationModel>? localizations)  $default,) {final _that = this;
switch (_that) {
case _RatingTagModel():
return $default(_that.id,_that.code,_that.name,_that.localizations);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( int id,  String code,  String? name,  List<RatingTagLocalizationModel>? localizations)?  $default,) {final _that = this;
switch (_that) {
case _RatingTagModel() when $default != null:
return $default(_that.id,_that.code,_that.name,_that.localizations);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _RatingTagModel extends RatingTagModel {
  const _RatingTagModel({required this.id, required this.code, this.name, final  List<RatingTagLocalizationModel>? localizations}): _localizations = localizations,super._();
  factory _RatingTagModel.fromJson(Map<String, dynamic> json) => _$RatingTagModelFromJson(json);

@override final  int id;
@override final  String code;
@override final  String? name;
 final  List<RatingTagLocalizationModel>? _localizations;
@override List<RatingTagLocalizationModel>? get localizations {
  final value = _localizations;
  if (value == null) return null;
  if (_localizations is EqualUnmodifiableListView) return _localizations;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(value);
}


/// Create a copy of RatingTagModel
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$RatingTagModelCopyWith<_RatingTagModel> get copyWith => __$RatingTagModelCopyWithImpl<_RatingTagModel>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$RatingTagModelToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _RatingTagModel&&(identical(other.id, id) || other.id == id)&&(identical(other.code, code) || other.code == code)&&(identical(other.name, name) || other.name == name)&&const DeepCollectionEquality().equals(other._localizations, _localizations));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,id,code,name,const DeepCollectionEquality().hash(_localizations));

@override
String toString() {
  return 'RatingTagModel(id: $id, code: $code, name: $name, localizations: $localizations)';
}


}

/// @nodoc
abstract mixin class _$RatingTagModelCopyWith<$Res> implements $RatingTagModelCopyWith<$Res> {
  factory _$RatingTagModelCopyWith(_RatingTagModel value, $Res Function(_RatingTagModel) _then) = __$RatingTagModelCopyWithImpl;
@override @useResult
$Res call({
 int id, String code, String? name, List<RatingTagLocalizationModel>? localizations
});




}
/// @nodoc
class __$RatingTagModelCopyWithImpl<$Res>
    implements _$RatingTagModelCopyWith<$Res> {
  __$RatingTagModelCopyWithImpl(this._self, this._then);

  final _RatingTagModel _self;
  final $Res Function(_RatingTagModel) _then;

/// Create a copy of RatingTagModel
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? id = null,Object? code = null,Object? name = freezed,Object? localizations = freezed,}) {
  return _then(_RatingTagModel(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as int,code: null == code ? _self.code : code // ignore: cast_nullable_to_non_nullable
as String,name: freezed == name ? _self.name : name // ignore: cast_nullable_to_non_nullable
as String?,localizations: freezed == localizations ? _self._localizations : localizations // ignore: cast_nullable_to_non_nullable
as List<RatingTagLocalizationModel>?,
  ));
}


}


/// @nodoc
mixin _$RatingTagLocalizationModel {

 String get languageCode; String get name;
/// Create a copy of RatingTagLocalizationModel
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$RatingTagLocalizationModelCopyWith<RatingTagLocalizationModel> get copyWith => _$RatingTagLocalizationModelCopyWithImpl<RatingTagLocalizationModel>(this as RatingTagLocalizationModel, _$identity);

  /// Serializes this RatingTagLocalizationModel to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is RatingTagLocalizationModel&&(identical(other.languageCode, languageCode) || other.languageCode == languageCode)&&(identical(other.name, name) || other.name == name));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,languageCode,name);

@override
String toString() {
  return 'RatingTagLocalizationModel(languageCode: $languageCode, name: $name)';
}


}

/// @nodoc
abstract mixin class $RatingTagLocalizationModelCopyWith<$Res>  {
  factory $RatingTagLocalizationModelCopyWith(RatingTagLocalizationModel value, $Res Function(RatingTagLocalizationModel) _then) = _$RatingTagLocalizationModelCopyWithImpl;
@useResult
$Res call({
 String languageCode, String name
});




}
/// @nodoc
class _$RatingTagLocalizationModelCopyWithImpl<$Res>
    implements $RatingTagLocalizationModelCopyWith<$Res> {
  _$RatingTagLocalizationModelCopyWithImpl(this._self, this._then);

  final RatingTagLocalizationModel _self;
  final $Res Function(RatingTagLocalizationModel) _then;

/// Create a copy of RatingTagLocalizationModel
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? languageCode = null,Object? name = null,}) {
  return _then(_self.copyWith(
languageCode: null == languageCode ? _self.languageCode : languageCode // ignore: cast_nullable_to_non_nullable
as String,name: null == name ? _self.name : name // ignore: cast_nullable_to_non_nullable
as String,
  ));
}

}


/// Adds pattern-matching-related methods to [RatingTagLocalizationModel].
extension RatingTagLocalizationModelPatterns on RatingTagLocalizationModel {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _RatingTagLocalizationModel value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _RatingTagLocalizationModel() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _RatingTagLocalizationModel value)  $default,){
final _that = this;
switch (_that) {
case _RatingTagLocalizationModel():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _RatingTagLocalizationModel value)?  $default,){
final _that = this;
switch (_that) {
case _RatingTagLocalizationModel() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String languageCode,  String name)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _RatingTagLocalizationModel() when $default != null:
return $default(_that.languageCode,_that.name);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String languageCode,  String name)  $default,) {final _that = this;
switch (_that) {
case _RatingTagLocalizationModel():
return $default(_that.languageCode,_that.name);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String languageCode,  String name)?  $default,) {final _that = this;
switch (_that) {
case _RatingTagLocalizationModel() when $default != null:
return $default(_that.languageCode,_that.name);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _RatingTagLocalizationModel implements RatingTagLocalizationModel {
  const _RatingTagLocalizationModel({required this.languageCode, required this.name});
  factory _RatingTagLocalizationModel.fromJson(Map<String, dynamic> json) => _$RatingTagLocalizationModelFromJson(json);

@override final  String languageCode;
@override final  String name;

/// Create a copy of RatingTagLocalizationModel
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$RatingTagLocalizationModelCopyWith<_RatingTagLocalizationModel> get copyWith => __$RatingTagLocalizationModelCopyWithImpl<_RatingTagLocalizationModel>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$RatingTagLocalizationModelToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _RatingTagLocalizationModel&&(identical(other.languageCode, languageCode) || other.languageCode == languageCode)&&(identical(other.name, name) || other.name == name));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,languageCode,name);

@override
String toString() {
  return 'RatingTagLocalizationModel(languageCode: $languageCode, name: $name)';
}


}

/// @nodoc
abstract mixin class _$RatingTagLocalizationModelCopyWith<$Res> implements $RatingTagLocalizationModelCopyWith<$Res> {
  factory _$RatingTagLocalizationModelCopyWith(_RatingTagLocalizationModel value, $Res Function(_RatingTagLocalizationModel) _then) = __$RatingTagLocalizationModelCopyWithImpl;
@override @useResult
$Res call({
 String languageCode, String name
});




}
/// @nodoc
class __$RatingTagLocalizationModelCopyWithImpl<$Res>
    implements _$RatingTagLocalizationModelCopyWith<$Res> {
  __$RatingTagLocalizationModelCopyWithImpl(this._self, this._then);

  final _RatingTagLocalizationModel _self;
  final $Res Function(_RatingTagLocalizationModel) _then;

/// Create a copy of RatingTagLocalizationModel
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? languageCode = null,Object? name = null,}) {
  return _then(_RatingTagLocalizationModel(
languageCode: null == languageCode ? _self.languageCode : languageCode // ignore: cast_nullable_to_non_nullable
as String,name: null == name ? _self.name : name // ignore: cast_nullable_to_non_nullable
as String,
  ));
}


}

// dart format on
