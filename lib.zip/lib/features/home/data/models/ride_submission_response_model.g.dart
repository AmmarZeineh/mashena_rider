// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ride_submission_response_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

RideSubmissionResponseModel _$RideSubmissionResponseModelFromJson(
  Map<String, dynamic> json,
) => RideSubmissionResponseModel(
  rideRequestId: _readInt(json['ride_request_id']),
  status: json['status'] as String,
  distanceKm: _readDouble(json['distance_km']),
  durationMin: _readDouble(json['duration_min']),
  isNight: _readBool(json['is_night']),
  estimatedFare: _readDouble(json['estimated_fare']),
  currency: json['currency'] as String,
);

Map<String, dynamic> _$RideSubmissionResponseModelToJson(
  RideSubmissionResponseModel instance,
) => <String, dynamic>{
  'ride_request_id': instance.rideRequestId,
  'status': instance.status,
  'distance_km': instance.distanceKm,
  'duration_min': instance.durationMin,
  'is_night': instance.isNight,
  'estimated_fare': instance.estimatedFare,
  'currency': instance.currency,
};
