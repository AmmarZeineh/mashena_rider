// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ride_estimate_response_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

RideEstimateResponseModel _$RideEstimateResponseModelFromJson(
  Map<String, dynamic> json,
) => RideEstimateResponseModel(
  rideRequestId: _readIntOptional(json['ride_request_id']),
  distanceKm: _readDouble(json['distance_km']),
  durationMin: _readDouble(json['duration_min']),
  stopsCount: _readInt(json['stops_count']),
  isNight: _readBool(json['is_night']),
  pickup: json['pickup'] == null
      ? null
      : RideLocationModel.fromJson(json['pickup'] as Map<String, dynamic>),
  destination: json['destination'] == null
      ? null
      : RideLocationModel.fromJson(json['destination'] as Map<String, dynamic>),
  estimates: json['estimates'] == null
      ? const []
      : _readEstimates(json['estimates']),
  polyline: json['polyline'] as String?,
  stops: json['stops'] == null ? const [] : _readStops(json['stops']),
  routePoints: json['route_points'] == null
      ? const []
      : _readRoutePoints(json['route_points']),
);

Map<String, dynamic> _$RideEstimateResponseModelToJson(
  RideEstimateResponseModel instance,
) => <String, dynamic>{
  'ride_request_id': instance.rideRequestId,
  'distance_km': instance.distanceKm,
  'duration_min': instance.durationMin,
  'stops_count': instance.stopsCount,
  'is_night': instance.isNight,
  'pickup': instance.pickup,
  'destination': instance.destination,
  'estimates': instance.estimates,
  'polyline': instance.polyline,
};
