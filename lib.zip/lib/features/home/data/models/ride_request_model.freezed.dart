// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'ride_request_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$RideRequestModel {

 RideLocationModel get pickup; RideLocationModel get destination; List<RideLocationModel> get stops;
/// Create a copy of RideRequestModel
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$RideRequestModelCopyWith<RideRequestModel> get copyWith => _$RideRequestModelCopyWithImpl<RideRequestModel>(this as RideRequestModel, _$identity);

  /// Serializes this RideRequestModel to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is RideRequestModel&&(identical(other.pickup, pickup) || other.pickup == pickup)&&(identical(other.destination, destination) || other.destination == destination)&&const DeepCollectionEquality().equals(other.stops, stops));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,pickup,destination,const DeepCollectionEquality().hash(stops));

@override
String toString() {
  return 'RideRequestModel(pickup: $pickup, destination: $destination, stops: $stops)';
}


}

/// @nodoc
abstract mixin class $RideRequestModelCopyWith<$Res>  {
  factory $RideRequestModelCopyWith(RideRequestModel value, $Res Function(RideRequestModel) _then) = _$RideRequestModelCopyWithImpl;
@useResult
$Res call({
 RideLocationModel pickup, RideLocationModel destination, List<RideLocationModel> stops
});


$RideLocationModelCopyWith<$Res> get pickup;$RideLocationModelCopyWith<$Res> get destination;

}
/// @nodoc
class _$RideRequestModelCopyWithImpl<$Res>
    implements $RideRequestModelCopyWith<$Res> {
  _$RideRequestModelCopyWithImpl(this._self, this._then);

  final RideRequestModel _self;
  final $Res Function(RideRequestModel) _then;

/// Create a copy of RideRequestModel
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? pickup = null,Object? destination = null,Object? stops = null,}) {
  return _then(_self.copyWith(
pickup: null == pickup ? _self.pickup : pickup // ignore: cast_nullable_to_non_nullable
as RideLocationModel,destination: null == destination ? _self.destination : destination // ignore: cast_nullable_to_non_nullable
as RideLocationModel,stops: null == stops ? _self.stops : stops // ignore: cast_nullable_to_non_nullable
as List<RideLocationModel>,
  ));
}
/// Create a copy of RideRequestModel
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$RideLocationModelCopyWith<$Res> get pickup {
  
  return $RideLocationModelCopyWith<$Res>(_self.pickup, (value) {
    return _then(_self.copyWith(pickup: value));
  });
}/// Create a copy of RideRequestModel
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$RideLocationModelCopyWith<$Res> get destination {
  
  return $RideLocationModelCopyWith<$Res>(_self.destination, (value) {
    return _then(_self.copyWith(destination: value));
  });
}
}


/// Adds pattern-matching-related methods to [RideRequestModel].
extension RideRequestModelPatterns on RideRequestModel {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _RideRequestModel value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _RideRequestModel() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _RideRequestModel value)  $default,){
final _that = this;
switch (_that) {
case _RideRequestModel():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _RideRequestModel value)?  $default,){
final _that = this;
switch (_that) {
case _RideRequestModel() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( RideLocationModel pickup,  RideLocationModel destination,  List<RideLocationModel> stops)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _RideRequestModel() when $default != null:
return $default(_that.pickup,_that.destination,_that.stops);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( RideLocationModel pickup,  RideLocationModel destination,  List<RideLocationModel> stops)  $default,) {final _that = this;
switch (_that) {
case _RideRequestModel():
return $default(_that.pickup,_that.destination,_that.stops);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( RideLocationModel pickup,  RideLocationModel destination,  List<RideLocationModel> stops)?  $default,) {final _that = this;
switch (_that) {
case _RideRequestModel() when $default != null:
return $default(_that.pickup,_that.destination,_that.stops);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _RideRequestModel implements RideRequestModel {
  const _RideRequestModel({required this.pickup, required this.destination, final  List<RideLocationModel> stops = const []}): _stops = stops;
  factory _RideRequestModel.fromJson(Map<String, dynamic> json) => _$RideRequestModelFromJson(json);

@override final  RideLocationModel pickup;
@override final  RideLocationModel destination;
 final  List<RideLocationModel> _stops;
@override@JsonKey() List<RideLocationModel> get stops {
  if (_stops is EqualUnmodifiableListView) return _stops;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_stops);
}


/// Create a copy of RideRequestModel
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$RideRequestModelCopyWith<_RideRequestModel> get copyWith => __$RideRequestModelCopyWithImpl<_RideRequestModel>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$RideRequestModelToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _RideRequestModel&&(identical(other.pickup, pickup) || other.pickup == pickup)&&(identical(other.destination, destination) || other.destination == destination)&&const DeepCollectionEquality().equals(other._stops, _stops));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,pickup,destination,const DeepCollectionEquality().hash(_stops));

@override
String toString() {
  return 'RideRequestModel(pickup: $pickup, destination: $destination, stops: $stops)';
}


}

/// @nodoc
abstract mixin class _$RideRequestModelCopyWith<$Res> implements $RideRequestModelCopyWith<$Res> {
  factory _$RideRequestModelCopyWith(_RideRequestModel value, $Res Function(_RideRequestModel) _then) = __$RideRequestModelCopyWithImpl;
@override @useResult
$Res call({
 RideLocationModel pickup, RideLocationModel destination, List<RideLocationModel> stops
});


@override $RideLocationModelCopyWith<$Res> get pickup;@override $RideLocationModelCopyWith<$Res> get destination;

}
/// @nodoc
class __$RideRequestModelCopyWithImpl<$Res>
    implements _$RideRequestModelCopyWith<$Res> {
  __$RideRequestModelCopyWithImpl(this._self, this._then);

  final _RideRequestModel _self;
  final $Res Function(_RideRequestModel) _then;

/// Create a copy of RideRequestModel
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? pickup = null,Object? destination = null,Object? stops = null,}) {
  return _then(_RideRequestModel(
pickup: null == pickup ? _self.pickup : pickup // ignore: cast_nullable_to_non_nullable
as RideLocationModel,destination: null == destination ? _self.destination : destination // ignore: cast_nullable_to_non_nullable
as RideLocationModel,stops: null == stops ? _self._stops : stops // ignore: cast_nullable_to_non_nullable
as List<RideLocationModel>,
  ));
}

/// Create a copy of RideRequestModel
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$RideLocationModelCopyWith<$Res> get pickup {
  
  return $RideLocationModelCopyWith<$Res>(_self.pickup, (value) {
    return _then(_self.copyWith(pickup: value));
  });
}/// Create a copy of RideRequestModel
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$RideLocationModelCopyWith<$Res> get destination {
  
  return $RideLocationModelCopyWith<$Res>(_self.destination, (value) {
    return _then(_self.copyWith(destination: value));
  });
}
}

// dart format on
