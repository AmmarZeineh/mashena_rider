// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ride_estimate_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

RideEstimateModel _$RideEstimateModelFromJson(Map<String, dynamic> json) =>
    RideEstimateModel(
      vehicleTypeId: _readInt(json['vehicle_type_id']),
      name: _readStringOrEmpty(json['name']),
      currency: _readStringOrEmpty(json['currency']),
      estimatedFare: _readDouble(json['estimated_fare']),
      imageUrl: _readImageUrl(json['image_url']),
    );

Map<String, dynamic> _$RideEstimateModelToJson(RideEstimateModel instance) =>
    <String, dynamic>{
      'vehicle_type_id': instance.vehicleTypeId,
      'name': instance.name,
      'image_url': instance.imageUrl,
      'currency': instance.currency,
      'estimated_fare': instance.estimatedFare,
    };
