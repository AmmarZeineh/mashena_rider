// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'trip_cancelled_payload.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$TripCancelledPayload {

 int get tripId; String? get canceledAt; String? get cancelledBy;
/// Create a copy of TripCancelledPayload
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$TripCancelledPayloadCopyWith<TripCancelledPayload> get copyWith => _$TripCancelledPayloadCopyWithImpl<TripCancelledPayload>(this as TripCancelledPayload, _$identity);

  /// Serializes this TripCancelledPayload to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is TripCancelledPayload&&(identical(other.tripId, tripId) || other.tripId == tripId)&&(identical(other.canceledAt, canceledAt) || other.canceledAt == canceledAt)&&(identical(other.cancelledBy, cancelledBy) || other.cancelledBy == cancelledBy));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,tripId,canceledAt,cancelledBy);

@override
String toString() {
  return 'TripCancelledPayload(tripId: $tripId, canceledAt: $canceledAt, cancelledBy: $cancelledBy)';
}


}

/// @nodoc
abstract mixin class $TripCancelledPayloadCopyWith<$Res>  {
  factory $TripCancelledPayloadCopyWith(TripCancelledPayload value, $Res Function(TripCancelledPayload) _then) = _$TripCancelledPayloadCopyWithImpl;
@useResult
$Res call({
 int tripId, String? canceledAt, String? cancelledBy
});




}
/// @nodoc
class _$TripCancelledPayloadCopyWithImpl<$Res>
    implements $TripCancelledPayloadCopyWith<$Res> {
  _$TripCancelledPayloadCopyWithImpl(this._self, this._then);

  final TripCancelledPayload _self;
  final $Res Function(TripCancelledPayload) _then;

/// Create a copy of TripCancelledPayload
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? tripId = null,Object? canceledAt = freezed,Object? cancelledBy = freezed,}) {
  return _then(_self.copyWith(
tripId: null == tripId ? _self.tripId : tripId // ignore: cast_nullable_to_non_nullable
as int,canceledAt: freezed == canceledAt ? _self.canceledAt : canceledAt // ignore: cast_nullable_to_non_nullable
as String?,cancelledBy: freezed == cancelledBy ? _self.cancelledBy : cancelledBy // ignore: cast_nullable_to_non_nullable
as String?,
  ));
}

}


/// Adds pattern-matching-related methods to [TripCancelledPayload].
extension TripCancelledPayloadPatterns on TripCancelledPayload {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _TripCancelledPayload value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _TripCancelledPayload() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _TripCancelledPayload value)  $default,){
final _that = this;
switch (_that) {
case _TripCancelledPayload():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _TripCancelledPayload value)?  $default,){
final _that = this;
switch (_that) {
case _TripCancelledPayload() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( int tripId,  String? canceledAt,  String? cancelledBy)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _TripCancelledPayload() when $default != null:
return $default(_that.tripId,_that.canceledAt,_that.cancelledBy);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( int tripId,  String? canceledAt,  String? cancelledBy)  $default,) {final _that = this;
switch (_that) {
case _TripCancelledPayload():
return $default(_that.tripId,_that.canceledAt,_that.cancelledBy);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( int tripId,  String? canceledAt,  String? cancelledBy)?  $default,) {final _that = this;
switch (_that) {
case _TripCancelledPayload() when $default != null:
return $default(_that.tripId,_that.canceledAt,_that.cancelledBy);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _TripCancelledPayload extends TripCancelledPayload {
  const _TripCancelledPayload({required this.tripId, this.canceledAt, this.cancelledBy}): super._();
  factory _TripCancelledPayload.fromJson(Map<String, dynamic> json) => _$TripCancelledPayloadFromJson(json);

@override final  int tripId;
@override final  String? canceledAt;
@override final  String? cancelledBy;

/// Create a copy of TripCancelledPayload
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$TripCancelledPayloadCopyWith<_TripCancelledPayload> get copyWith => __$TripCancelledPayloadCopyWithImpl<_TripCancelledPayload>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$TripCancelledPayloadToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _TripCancelledPayload&&(identical(other.tripId, tripId) || other.tripId == tripId)&&(identical(other.canceledAt, canceledAt) || other.canceledAt == canceledAt)&&(identical(other.cancelledBy, cancelledBy) || other.cancelledBy == cancelledBy));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,tripId,canceledAt,cancelledBy);

@override
String toString() {
  return 'TripCancelledPayload(tripId: $tripId, canceledAt: $canceledAt, cancelledBy: $cancelledBy)';
}


}

/// @nodoc
abstract mixin class _$TripCancelledPayloadCopyWith<$Res> implements $TripCancelledPayloadCopyWith<$Res> {
  factory _$TripCancelledPayloadCopyWith(_TripCancelledPayload value, $Res Function(_TripCancelledPayload) _then) = __$TripCancelledPayloadCopyWithImpl;
@override @useResult
$Res call({
 int tripId, String? canceledAt, String? cancelledBy
});




}
/// @nodoc
class __$TripCancelledPayloadCopyWithImpl<$Res>
    implements _$TripCancelledPayloadCopyWith<$Res> {
  __$TripCancelledPayloadCopyWithImpl(this._self, this._then);

  final _TripCancelledPayload _self;
  final $Res Function(_TripCancelledPayload) _then;

/// Create a copy of TripCancelledPayload
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? tripId = null,Object? canceledAt = freezed,Object? cancelledBy = freezed,}) {
  return _then(_TripCancelledPayload(
tripId: null == tripId ? _self.tripId : tripId // ignore: cast_nullable_to_non_nullable
as int,canceledAt: freezed == canceledAt ? _self.canceledAt : canceledAt // ignore: cast_nullable_to_non_nullable
as String?,cancelledBy: freezed == cancelledBy ? _self.cancelledBy : cancelledBy // ignore: cast_nullable_to_non_nullable
as String?,
  ));
}


}

// dart format on
