// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'rating_tag_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_RatingTagModel _$RatingTagModelFromJson(Map<String, dynamic> json) =>
    _RatingTagModel(
      id: (json['id'] as num).toInt(),
      code: json['code'] as String,
      name: json['name'] as String?,
      localizations: (json['localizations'] as List<dynamic>?)
          ?.map(
            (e) =>
                RatingTagLocalizationModel.fromJson(e as Map<String, dynamic>),
          )
          .toList(),
    );

Map<String, dynamic> _$RatingTagModelToJson(_RatingTagModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'code': instance.code,
      'name': instance.name,
      'localizations': instance.localizations,
    };

_RatingTagLocalizationModel _$RatingTagLocalizationModelFromJson(
  Map<String, dynamic> json,
) => _RatingTagLocalizationModel(
  languageCode: json['languageCode'] as String,
  name: json['name'] as String,
);

Map<String, dynamic> _$RatingTagLocalizationModelToJson(
  _RatingTagLocalizationModel instance,
) => <String, dynamic>{
  'languageCode': instance.languageCode,
  'name': instance.name,
};
