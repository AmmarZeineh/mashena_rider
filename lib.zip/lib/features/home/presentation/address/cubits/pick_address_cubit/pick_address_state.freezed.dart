// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'pick_address_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$PickAddressState {

 PlaceEntity? get pickupPlace; List<PlaceEntity?> get destinations; int get activeFieldIndex; String get searchQuery; List<PlaceEntity> get searchResults; bool get isSearching; bool get isReversingGeocode; bool get isCreatingRideRequest; RideEstimateResponse? get rideEstimateResponse; RideRequest? get rideRequest; RideEstimate? get selectedRideEstimate; Failure? get errorMessage; String? get warningMessage;
/// Create a copy of PickAddressState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$PickAddressStateCopyWith<PickAddressState> get copyWith => _$PickAddressStateCopyWithImpl<PickAddressState>(this as PickAddressState, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is PickAddressState&&(identical(other.pickupPlace, pickupPlace) || other.pickupPlace == pickupPlace)&&const DeepCollectionEquality().equals(other.destinations, destinations)&&(identical(other.activeFieldIndex, activeFieldIndex) || other.activeFieldIndex == activeFieldIndex)&&(identical(other.searchQuery, searchQuery) || other.searchQuery == searchQuery)&&const DeepCollectionEquality().equals(other.searchResults, searchResults)&&(identical(other.isSearching, isSearching) || other.isSearching == isSearching)&&(identical(other.isReversingGeocode, isReversingGeocode) || other.isReversingGeocode == isReversingGeocode)&&(identical(other.isCreatingRideRequest, isCreatingRideRequest) || other.isCreatingRideRequest == isCreatingRideRequest)&&(identical(other.rideEstimateResponse, rideEstimateResponse) || other.rideEstimateResponse == rideEstimateResponse)&&(identical(other.rideRequest, rideRequest) || other.rideRequest == rideRequest)&&(identical(other.selectedRideEstimate, selectedRideEstimate) || other.selectedRideEstimate == selectedRideEstimate)&&(identical(other.errorMessage, errorMessage) || other.errorMessage == errorMessage)&&(identical(other.warningMessage, warningMessage) || other.warningMessage == warningMessage));
}


@override
int get hashCode => Object.hash(runtimeType,pickupPlace,const DeepCollectionEquality().hash(destinations),activeFieldIndex,searchQuery,const DeepCollectionEquality().hash(searchResults),isSearching,isReversingGeocode,isCreatingRideRequest,rideEstimateResponse,rideRequest,selectedRideEstimate,errorMessage,warningMessage);

@override
String toString() {
  return 'PickAddressState(pickupPlace: $pickupPlace, destinations: $destinations, activeFieldIndex: $activeFieldIndex, searchQuery: $searchQuery, searchResults: $searchResults, isSearching: $isSearching, isReversingGeocode: $isReversingGeocode, isCreatingRideRequest: $isCreatingRideRequest, rideEstimateResponse: $rideEstimateResponse, rideRequest: $rideRequest, selectedRideEstimate: $selectedRideEstimate, errorMessage: $errorMessage, warningMessage: $warningMessage)';
}


}

/// @nodoc
abstract mixin class $PickAddressStateCopyWith<$Res>  {
  factory $PickAddressStateCopyWith(PickAddressState value, $Res Function(PickAddressState) _then) = _$PickAddressStateCopyWithImpl;
@useResult
$Res call({
 PlaceEntity? pickupPlace, List<PlaceEntity?> destinations, int activeFieldIndex, String searchQuery, List<PlaceEntity> searchResults, bool isSearching, bool isReversingGeocode, bool isCreatingRideRequest, RideEstimateResponse? rideEstimateResponse, RideRequest? rideRequest, RideEstimate? selectedRideEstimate, Failure? errorMessage, String? warningMessage
});


$RideRequestCopyWith<$Res>? get rideRequest;

}
/// @nodoc
class _$PickAddressStateCopyWithImpl<$Res>
    implements $PickAddressStateCopyWith<$Res> {
  _$PickAddressStateCopyWithImpl(this._self, this._then);

  final PickAddressState _self;
  final $Res Function(PickAddressState) _then;

/// Create a copy of PickAddressState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? pickupPlace = freezed,Object? destinations = null,Object? activeFieldIndex = null,Object? searchQuery = null,Object? searchResults = null,Object? isSearching = null,Object? isReversingGeocode = null,Object? isCreatingRideRequest = null,Object? rideEstimateResponse = freezed,Object? rideRequest = freezed,Object? selectedRideEstimate = freezed,Object? errorMessage = freezed,Object? warningMessage = freezed,}) {
  return _then(_self.copyWith(
pickupPlace: freezed == pickupPlace ? _self.pickupPlace : pickupPlace // ignore: cast_nullable_to_non_nullable
as PlaceEntity?,destinations: null == destinations ? _self.destinations : destinations // ignore: cast_nullable_to_non_nullable
as List<PlaceEntity?>,activeFieldIndex: null == activeFieldIndex ? _self.activeFieldIndex : activeFieldIndex // ignore: cast_nullable_to_non_nullable
as int,searchQuery: null == searchQuery ? _self.searchQuery : searchQuery // ignore: cast_nullable_to_non_nullable
as String,searchResults: null == searchResults ? _self.searchResults : searchResults // ignore: cast_nullable_to_non_nullable
as List<PlaceEntity>,isSearching: null == isSearching ? _self.isSearching : isSearching // ignore: cast_nullable_to_non_nullable
as bool,isReversingGeocode: null == isReversingGeocode ? _self.isReversingGeocode : isReversingGeocode // ignore: cast_nullable_to_non_nullable
as bool,isCreatingRideRequest: null == isCreatingRideRequest ? _self.isCreatingRideRequest : isCreatingRideRequest // ignore: cast_nullable_to_non_nullable
as bool,rideEstimateResponse: freezed == rideEstimateResponse ? _self.rideEstimateResponse : rideEstimateResponse // ignore: cast_nullable_to_non_nullable
as RideEstimateResponse?,rideRequest: freezed == rideRequest ? _self.rideRequest : rideRequest // ignore: cast_nullable_to_non_nullable
as RideRequest?,selectedRideEstimate: freezed == selectedRideEstimate ? _self.selectedRideEstimate : selectedRideEstimate // ignore: cast_nullable_to_non_nullable
as RideEstimate?,errorMessage: freezed == errorMessage ? _self.errorMessage : errorMessage // ignore: cast_nullable_to_non_nullable
as Failure?,warningMessage: freezed == warningMessage ? _self.warningMessage : warningMessage // ignore: cast_nullable_to_non_nullable
as String?,
  ));
}
/// Create a copy of PickAddressState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$RideRequestCopyWith<$Res>? get rideRequest {
    if (_self.rideRequest == null) {
    return null;
  }

  return $RideRequestCopyWith<$Res>(_self.rideRequest!, (value) {
    return _then(_self.copyWith(rideRequest: value));
  });
}
}


/// Adds pattern-matching-related methods to [PickAddressState].
extension PickAddressStatePatterns on PickAddressState {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _PickAddressState value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _PickAddressState() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _PickAddressState value)  $default,){
final _that = this;
switch (_that) {
case _PickAddressState():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _PickAddressState value)?  $default,){
final _that = this;
switch (_that) {
case _PickAddressState() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( PlaceEntity? pickupPlace,  List<PlaceEntity?> destinations,  int activeFieldIndex,  String searchQuery,  List<PlaceEntity> searchResults,  bool isSearching,  bool isReversingGeocode,  bool isCreatingRideRequest,  RideEstimateResponse? rideEstimateResponse,  RideRequest? rideRequest,  RideEstimate? selectedRideEstimate,  Failure? errorMessage,  String? warningMessage)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _PickAddressState() when $default != null:
return $default(_that.pickupPlace,_that.destinations,_that.activeFieldIndex,_that.searchQuery,_that.searchResults,_that.isSearching,_that.isReversingGeocode,_that.isCreatingRideRequest,_that.rideEstimateResponse,_that.rideRequest,_that.selectedRideEstimate,_that.errorMessage,_that.warningMessage);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( PlaceEntity? pickupPlace,  List<PlaceEntity?> destinations,  int activeFieldIndex,  String searchQuery,  List<PlaceEntity> searchResults,  bool isSearching,  bool isReversingGeocode,  bool isCreatingRideRequest,  RideEstimateResponse? rideEstimateResponse,  RideRequest? rideRequest,  RideEstimate? selectedRideEstimate,  Failure? errorMessage,  String? warningMessage)  $default,) {final _that = this;
switch (_that) {
case _PickAddressState():
return $default(_that.pickupPlace,_that.destinations,_that.activeFieldIndex,_that.searchQuery,_that.searchResults,_that.isSearching,_that.isReversingGeocode,_that.isCreatingRideRequest,_that.rideEstimateResponse,_that.rideRequest,_that.selectedRideEstimate,_that.errorMessage,_that.warningMessage);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( PlaceEntity? pickupPlace,  List<PlaceEntity?> destinations,  int activeFieldIndex,  String searchQuery,  List<PlaceEntity> searchResults,  bool isSearching,  bool isReversingGeocode,  bool isCreatingRideRequest,  RideEstimateResponse? rideEstimateResponse,  RideRequest? rideRequest,  RideEstimate? selectedRideEstimate,  Failure? errorMessage,  String? warningMessage)?  $default,) {final _that = this;
switch (_that) {
case _PickAddressState() when $default != null:
return $default(_that.pickupPlace,_that.destinations,_that.activeFieldIndex,_that.searchQuery,_that.searchResults,_that.isSearching,_that.isReversingGeocode,_that.isCreatingRideRequest,_that.rideEstimateResponse,_that.rideRequest,_that.selectedRideEstimate,_that.errorMessage,_that.warningMessage);case _:
  return null;

}
}

}

/// @nodoc


class _PickAddressState implements PickAddressState {
  const _PickAddressState({this.pickupPlace, final  List<PlaceEntity?> destinations = const [null], this.activeFieldIndex = 0, this.searchQuery = '', final  List<PlaceEntity> searchResults = const [], this.isSearching = false, this.isReversingGeocode = false, this.isCreatingRideRequest = false, this.rideEstimateResponse, this.rideRequest, this.selectedRideEstimate, this.errorMessage, this.warningMessage}): _destinations = destinations,_searchResults = searchResults;
  

@override final  PlaceEntity? pickupPlace;
 final  List<PlaceEntity?> _destinations;
@override@JsonKey() List<PlaceEntity?> get destinations {
  if (_destinations is EqualUnmodifiableListView) return _destinations;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_destinations);
}

@override@JsonKey() final  int activeFieldIndex;
@override@JsonKey() final  String searchQuery;
 final  List<PlaceEntity> _searchResults;
@override@JsonKey() List<PlaceEntity> get searchResults {
  if (_searchResults is EqualUnmodifiableListView) return _searchResults;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_searchResults);
}

@override@JsonKey() final  bool isSearching;
@override@JsonKey() final  bool isReversingGeocode;
@override@JsonKey() final  bool isCreatingRideRequest;
@override final  RideEstimateResponse? rideEstimateResponse;
@override final  RideRequest? rideRequest;
@override final  RideEstimate? selectedRideEstimate;
@override final  Failure? errorMessage;
@override final  String? warningMessage;

/// Create a copy of PickAddressState
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$PickAddressStateCopyWith<_PickAddressState> get copyWith => __$PickAddressStateCopyWithImpl<_PickAddressState>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _PickAddressState&&(identical(other.pickupPlace, pickupPlace) || other.pickupPlace == pickupPlace)&&const DeepCollectionEquality().equals(other._destinations, _destinations)&&(identical(other.activeFieldIndex, activeFieldIndex) || other.activeFieldIndex == activeFieldIndex)&&(identical(other.searchQuery, searchQuery) || other.searchQuery == searchQuery)&&const DeepCollectionEquality().equals(other._searchResults, _searchResults)&&(identical(other.isSearching, isSearching) || other.isSearching == isSearching)&&(identical(other.isReversingGeocode, isReversingGeocode) || other.isReversingGeocode == isReversingGeocode)&&(identical(other.isCreatingRideRequest, isCreatingRideRequest) || other.isCreatingRideRequest == isCreatingRideRequest)&&(identical(other.rideEstimateResponse, rideEstimateResponse) || other.rideEstimateResponse == rideEstimateResponse)&&(identical(other.rideRequest, rideRequest) || other.rideRequest == rideRequest)&&(identical(other.selectedRideEstimate, selectedRideEstimate) || other.selectedRideEstimate == selectedRideEstimate)&&(identical(other.errorMessage, errorMessage) || other.errorMessage == errorMessage)&&(identical(other.warningMessage, warningMessage) || other.warningMessage == warningMessage));
}


@override
int get hashCode => Object.hash(runtimeType,pickupPlace,const DeepCollectionEquality().hash(_destinations),activeFieldIndex,searchQuery,const DeepCollectionEquality().hash(_searchResults),isSearching,isReversingGeocode,isCreatingRideRequest,rideEstimateResponse,rideRequest,selectedRideEstimate,errorMessage,warningMessage);

@override
String toString() {
  return 'PickAddressState(pickupPlace: $pickupPlace, destinations: $destinations, activeFieldIndex: $activeFieldIndex, searchQuery: $searchQuery, searchResults: $searchResults, isSearching: $isSearching, isReversingGeocode: $isReversingGeocode, isCreatingRideRequest: $isCreatingRideRequest, rideEstimateResponse: $rideEstimateResponse, rideRequest: $rideRequest, selectedRideEstimate: $selectedRideEstimate, errorMessage: $errorMessage, warningMessage: $warningMessage)';
}


}

/// @nodoc
abstract mixin class _$PickAddressStateCopyWith<$Res> implements $PickAddressStateCopyWith<$Res> {
  factory _$PickAddressStateCopyWith(_PickAddressState value, $Res Function(_PickAddressState) _then) = __$PickAddressStateCopyWithImpl;
@override @useResult
$Res call({
 PlaceEntity? pickupPlace, List<PlaceEntity?> destinations, int activeFieldIndex, String searchQuery, List<PlaceEntity> searchResults, bool isSearching, bool isReversingGeocode, bool isCreatingRideRequest, RideEstimateResponse? rideEstimateResponse, RideRequest? rideRequest, RideEstimate? selectedRideEstimate, Failure? errorMessage, String? warningMessage
});


@override $RideRequestCopyWith<$Res>? get rideRequest;

}
/// @nodoc
class __$PickAddressStateCopyWithImpl<$Res>
    implements _$PickAddressStateCopyWith<$Res> {
  __$PickAddressStateCopyWithImpl(this._self, this._then);

  final _PickAddressState _self;
  final $Res Function(_PickAddressState) _then;

/// Create a copy of PickAddressState
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? pickupPlace = freezed,Object? destinations = null,Object? activeFieldIndex = null,Object? searchQuery = null,Object? searchResults = null,Object? isSearching = null,Object? isReversingGeocode = null,Object? isCreatingRideRequest = null,Object? rideEstimateResponse = freezed,Object? rideRequest = freezed,Object? selectedRideEstimate = freezed,Object? errorMessage = freezed,Object? warningMessage = freezed,}) {
  return _then(_PickAddressState(
pickupPlace: freezed == pickupPlace ? _self.pickupPlace : pickupPlace // ignore: cast_nullable_to_non_nullable
as PlaceEntity?,destinations: null == destinations ? _self._destinations : destinations // ignore: cast_nullable_to_non_nullable
as List<PlaceEntity?>,activeFieldIndex: null == activeFieldIndex ? _self.activeFieldIndex : activeFieldIndex // ignore: cast_nullable_to_non_nullable
as int,searchQuery: null == searchQuery ? _self.searchQuery : searchQuery // ignore: cast_nullable_to_non_nullable
as String,searchResults: null == searchResults ? _self._searchResults : searchResults // ignore: cast_nullable_to_non_nullable
as List<PlaceEntity>,isSearching: null == isSearching ? _self.isSearching : isSearching // ignore: cast_nullable_to_non_nullable
as bool,isReversingGeocode: null == isReversingGeocode ? _self.isReversingGeocode : isReversingGeocode // ignore: cast_nullable_to_non_nullable
as bool,isCreatingRideRequest: null == isCreatingRideRequest ? _self.isCreatingRideRequest : isCreatingRideRequest // ignore: cast_nullable_to_non_nullable
as bool,rideEstimateResponse: freezed == rideEstimateResponse ? _self.rideEstimateResponse : rideEstimateResponse // ignore: cast_nullable_to_non_nullable
as RideEstimateResponse?,rideRequest: freezed == rideRequest ? _self.rideRequest : rideRequest // ignore: cast_nullable_to_non_nullable
as RideRequest?,selectedRideEstimate: freezed == selectedRideEstimate ? _self.selectedRideEstimate : selectedRideEstimate // ignore: cast_nullable_to_non_nullable
as RideEstimate?,errorMessage: freezed == errorMessage ? _self.errorMessage : errorMessage // ignore: cast_nullable_to_non_nullable
as Failure?,warningMessage: freezed == warningMessage ? _self.warningMessage : warningMessage // ignore: cast_nullable_to_non_nullable
as String?,
  ));
}

/// Create a copy of PickAddressState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$RideRequestCopyWith<$Res>? get rideRequest {
    if (_self.rideRequest == null) {
    return null;
  }

  return $RideRequestCopyWith<$Res>(_self.rideRequest!, (value) {
    return _then(_self.copyWith(rideRequest: value));
  });
}
}

// dart format on
