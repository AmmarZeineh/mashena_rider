// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'rider_profile_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$RiderProfileModel {

 int get id; String get fullName; String get email; String get phoneNumber; DateTime get createdAt; RiderProfileDto? get riderProfile;
/// Create a copy of RiderProfileModel
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$RiderProfileModelCopyWith<RiderProfileModel> get copyWith => _$RiderProfileModelCopyWithImpl<RiderProfileModel>(this as RiderProfileModel, _$identity);

  /// Serializes this RiderProfileModel to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is RiderProfileModel&&(identical(other.id, id) || other.id == id)&&(identical(other.fullName, fullName) || other.fullName == fullName)&&(identical(other.email, email) || other.email == email)&&(identical(other.phoneNumber, phoneNumber) || other.phoneNumber == phoneNumber)&&(identical(other.createdAt, createdAt) || other.createdAt == createdAt)&&(identical(other.riderProfile, riderProfile) || other.riderProfile == riderProfile));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,id,fullName,email,phoneNumber,createdAt,riderProfile);

@override
String toString() {
  return 'RiderProfileModel(id: $id, fullName: $fullName, email: $email, phoneNumber: $phoneNumber, createdAt: $createdAt, riderProfile: $riderProfile)';
}


}

/// @nodoc
abstract mixin class $RiderProfileModelCopyWith<$Res>  {
  factory $RiderProfileModelCopyWith(RiderProfileModel value, $Res Function(RiderProfileModel) _then) = _$RiderProfileModelCopyWithImpl;
@useResult
$Res call({
 int id, String fullName, String email, String phoneNumber, DateTime createdAt, RiderProfileDto? riderProfile
});


$RiderProfileDtoCopyWith<$Res>? get riderProfile;

}
/// @nodoc
class _$RiderProfileModelCopyWithImpl<$Res>
    implements $RiderProfileModelCopyWith<$Res> {
  _$RiderProfileModelCopyWithImpl(this._self, this._then);

  final RiderProfileModel _self;
  final $Res Function(RiderProfileModel) _then;

/// Create a copy of RiderProfileModel
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? id = null,Object? fullName = null,Object? email = null,Object? phoneNumber = null,Object? createdAt = null,Object? riderProfile = freezed,}) {
  return _then(_self.copyWith(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as int,fullName: null == fullName ? _self.fullName : fullName // ignore: cast_nullable_to_non_nullable
as String,email: null == email ? _self.email : email // ignore: cast_nullable_to_non_nullable
as String,phoneNumber: null == phoneNumber ? _self.phoneNumber : phoneNumber // ignore: cast_nullable_to_non_nullable
as String,createdAt: null == createdAt ? _self.createdAt : createdAt // ignore: cast_nullable_to_non_nullable
as DateTime,riderProfile: freezed == riderProfile ? _self.riderProfile : riderProfile // ignore: cast_nullable_to_non_nullable
as RiderProfileDto?,
  ));
}
/// Create a copy of RiderProfileModel
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$RiderProfileDtoCopyWith<$Res>? get riderProfile {
    if (_self.riderProfile == null) {
    return null;
  }

  return $RiderProfileDtoCopyWith<$Res>(_self.riderProfile!, (value) {
    return _then(_self.copyWith(riderProfile: value));
  });
}
}


/// Adds pattern-matching-related methods to [RiderProfileModel].
extension RiderProfileModelPatterns on RiderProfileModel {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _RiderProfileModel value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _RiderProfileModel() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _RiderProfileModel value)  $default,){
final _that = this;
switch (_that) {
case _RiderProfileModel():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _RiderProfileModel value)?  $default,){
final _that = this;
switch (_that) {
case _RiderProfileModel() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( int id,  String fullName,  String email,  String phoneNumber,  DateTime createdAt,  RiderProfileDto? riderProfile)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _RiderProfileModel() when $default != null:
return $default(_that.id,_that.fullName,_that.email,_that.phoneNumber,_that.createdAt,_that.riderProfile);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( int id,  String fullName,  String email,  String phoneNumber,  DateTime createdAt,  RiderProfileDto? riderProfile)  $default,) {final _that = this;
switch (_that) {
case _RiderProfileModel():
return $default(_that.id,_that.fullName,_that.email,_that.phoneNumber,_that.createdAt,_that.riderProfile);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( int id,  String fullName,  String email,  String phoneNumber,  DateTime createdAt,  RiderProfileDto? riderProfile)?  $default,) {final _that = this;
switch (_that) {
case _RiderProfileModel() when $default != null:
return $default(_that.id,_that.fullName,_that.email,_that.phoneNumber,_that.createdAt,_that.riderProfile);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _RiderProfileModel extends RiderProfileModel {
  const _RiderProfileModel({required this.id, required this.fullName, required this.email, required this.phoneNumber, required this.createdAt, this.riderProfile}): super._();
  factory _RiderProfileModel.fromJson(Map<String, dynamic> json) => _$RiderProfileModelFromJson(json);

@override final  int id;
@override final  String fullName;
@override final  String email;
@override final  String phoneNumber;
@override final  DateTime createdAt;
@override final  RiderProfileDto? riderProfile;

/// Create a copy of RiderProfileModel
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$RiderProfileModelCopyWith<_RiderProfileModel> get copyWith => __$RiderProfileModelCopyWithImpl<_RiderProfileModel>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$RiderProfileModelToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _RiderProfileModel&&(identical(other.id, id) || other.id == id)&&(identical(other.fullName, fullName) || other.fullName == fullName)&&(identical(other.email, email) || other.email == email)&&(identical(other.phoneNumber, phoneNumber) || other.phoneNumber == phoneNumber)&&(identical(other.createdAt, createdAt) || other.createdAt == createdAt)&&(identical(other.riderProfile, riderProfile) || other.riderProfile == riderProfile));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,id,fullName,email,phoneNumber,createdAt,riderProfile);

@override
String toString() {
  return 'RiderProfileModel(id: $id, fullName: $fullName, email: $email, phoneNumber: $phoneNumber, createdAt: $createdAt, riderProfile: $riderProfile)';
}


}

/// @nodoc
abstract mixin class _$RiderProfileModelCopyWith<$Res> implements $RiderProfileModelCopyWith<$Res> {
  factory _$RiderProfileModelCopyWith(_RiderProfileModel value, $Res Function(_RiderProfileModel) _then) = __$RiderProfileModelCopyWithImpl;
@override @useResult
$Res call({
 int id, String fullName, String email, String phoneNumber, DateTime createdAt, RiderProfileDto? riderProfile
});


@override $RiderProfileDtoCopyWith<$Res>? get riderProfile;

}
/// @nodoc
class __$RiderProfileModelCopyWithImpl<$Res>
    implements _$RiderProfileModelCopyWith<$Res> {
  __$RiderProfileModelCopyWithImpl(this._self, this._then);

  final _RiderProfileModel _self;
  final $Res Function(_RiderProfileModel) _then;

/// Create a copy of RiderProfileModel
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? id = null,Object? fullName = null,Object? email = null,Object? phoneNumber = null,Object? createdAt = null,Object? riderProfile = freezed,}) {
  return _then(_RiderProfileModel(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as int,fullName: null == fullName ? _self.fullName : fullName // ignore: cast_nullable_to_non_nullable
as String,email: null == email ? _self.email : email // ignore: cast_nullable_to_non_nullable
as String,phoneNumber: null == phoneNumber ? _self.phoneNumber : phoneNumber // ignore: cast_nullable_to_non_nullable
as String,createdAt: null == createdAt ? _self.createdAt : createdAt // ignore: cast_nullable_to_non_nullable
as DateTime,riderProfile: freezed == riderProfile ? _self.riderProfile : riderProfile // ignore: cast_nullable_to_non_nullable
as RiderProfileDto?,
  ));
}

/// Create a copy of RiderProfileModel
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$RiderProfileDtoCopyWith<$Res>? get riderProfile {
    if (_self.riderProfile == null) {
    return null;
  }

  return $RiderProfileDtoCopyWith<$Res>(_self.riderProfile!, (value) {
    return _then(_self.copyWith(riderProfile: value));
  });
}
}


/// @nodoc
mixin _$RiderProfileDto {

 double? get ratingAvg; int? get ratingCount; int? get canceledTripsCount;
/// Create a copy of RiderProfileDto
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$RiderProfileDtoCopyWith<RiderProfileDto> get copyWith => _$RiderProfileDtoCopyWithImpl<RiderProfileDto>(this as RiderProfileDto, _$identity);

  /// Serializes this RiderProfileDto to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is RiderProfileDto&&(identical(other.ratingAvg, ratingAvg) || other.ratingAvg == ratingAvg)&&(identical(other.ratingCount, ratingCount) || other.ratingCount == ratingCount)&&(identical(other.canceledTripsCount, canceledTripsCount) || other.canceledTripsCount == canceledTripsCount));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,ratingAvg,ratingCount,canceledTripsCount);

@override
String toString() {
  return 'RiderProfileDto(ratingAvg: $ratingAvg, ratingCount: $ratingCount, canceledTripsCount: $canceledTripsCount)';
}


}

/// @nodoc
abstract mixin class $RiderProfileDtoCopyWith<$Res>  {
  factory $RiderProfileDtoCopyWith(RiderProfileDto value, $Res Function(RiderProfileDto) _then) = _$RiderProfileDtoCopyWithImpl;
@useResult
$Res call({
 double? ratingAvg, int? ratingCount, int? canceledTripsCount
});




}
/// @nodoc
class _$RiderProfileDtoCopyWithImpl<$Res>
    implements $RiderProfileDtoCopyWith<$Res> {
  _$RiderProfileDtoCopyWithImpl(this._self, this._then);

  final RiderProfileDto _self;
  final $Res Function(RiderProfileDto) _then;

/// Create a copy of RiderProfileDto
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? ratingAvg = freezed,Object? ratingCount = freezed,Object? canceledTripsCount = freezed,}) {
  return _then(_self.copyWith(
ratingAvg: freezed == ratingAvg ? _self.ratingAvg : ratingAvg // ignore: cast_nullable_to_non_nullable
as double?,ratingCount: freezed == ratingCount ? _self.ratingCount : ratingCount // ignore: cast_nullable_to_non_nullable
as int?,canceledTripsCount: freezed == canceledTripsCount ? _self.canceledTripsCount : canceledTripsCount // ignore: cast_nullable_to_non_nullable
as int?,
  ));
}

}


/// Adds pattern-matching-related methods to [RiderProfileDto].
extension RiderProfileDtoPatterns on RiderProfileDto {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _RiderProfileDto value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _RiderProfileDto() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _RiderProfileDto value)  $default,){
final _that = this;
switch (_that) {
case _RiderProfileDto():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _RiderProfileDto value)?  $default,){
final _that = this;
switch (_that) {
case _RiderProfileDto() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( double? ratingAvg,  int? ratingCount,  int? canceledTripsCount)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _RiderProfileDto() when $default != null:
return $default(_that.ratingAvg,_that.ratingCount,_that.canceledTripsCount);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( double? ratingAvg,  int? ratingCount,  int? canceledTripsCount)  $default,) {final _that = this;
switch (_that) {
case _RiderProfileDto():
return $default(_that.ratingAvg,_that.ratingCount,_that.canceledTripsCount);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( double? ratingAvg,  int? ratingCount,  int? canceledTripsCount)?  $default,) {final _that = this;
switch (_that) {
case _RiderProfileDto() when $default != null:
return $default(_that.ratingAvg,_that.ratingCount,_that.canceledTripsCount);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _RiderProfileDto implements RiderProfileDto {
  const _RiderProfileDto({this.ratingAvg, this.ratingCount, this.canceledTripsCount});
  factory _RiderProfileDto.fromJson(Map<String, dynamic> json) => _$RiderProfileDtoFromJson(json);

@override final  double? ratingAvg;
@override final  int? ratingCount;
@override final  int? canceledTripsCount;

/// Create a copy of RiderProfileDto
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$RiderProfileDtoCopyWith<_RiderProfileDto> get copyWith => __$RiderProfileDtoCopyWithImpl<_RiderProfileDto>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$RiderProfileDtoToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _RiderProfileDto&&(identical(other.ratingAvg, ratingAvg) || other.ratingAvg == ratingAvg)&&(identical(other.ratingCount, ratingCount) || other.ratingCount == ratingCount)&&(identical(other.canceledTripsCount, canceledTripsCount) || other.canceledTripsCount == canceledTripsCount));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,ratingAvg,ratingCount,canceledTripsCount);

@override
String toString() {
  return 'RiderProfileDto(ratingAvg: $ratingAvg, ratingCount: $ratingCount, canceledTripsCount: $canceledTripsCount)';
}


}

/// @nodoc
abstract mixin class _$RiderProfileDtoCopyWith<$Res> implements $RiderProfileDtoCopyWith<$Res> {
  factory _$RiderProfileDtoCopyWith(_RiderProfileDto value, $Res Function(_RiderProfileDto) _then) = __$RiderProfileDtoCopyWithImpl;
@override @useResult
$Res call({
 double? ratingAvg, int? ratingCount, int? canceledTripsCount
});




}
/// @nodoc
class __$RiderProfileDtoCopyWithImpl<$Res>
    implements _$RiderProfileDtoCopyWith<$Res> {
  __$RiderProfileDtoCopyWithImpl(this._self, this._then);

  final _RiderProfileDto _self;
  final $Res Function(_RiderProfileDto) _then;

/// Create a copy of RiderProfileDto
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? ratingAvg = freezed,Object? ratingCount = freezed,Object? canceledTripsCount = freezed,}) {
  return _then(_RiderProfileDto(
ratingAvg: freezed == ratingAvg ? _self.ratingAvg : ratingAvg // ignore: cast_nullable_to_non_nullable
as double?,ratingCount: freezed == ratingCount ? _self.ratingCount : ratingCount // ignore: cast_nullable_to_non_nullable
as int?,canceledTripsCount: freezed == canceledTripsCount ? _self.canceledTripsCount : canceledTripsCount // ignore: cast_nullable_to_non_nullable
as int?,
  ));
}


}

// dart format on
