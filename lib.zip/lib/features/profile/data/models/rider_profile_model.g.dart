// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'rider_profile_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_RiderProfileModel _$RiderProfileModelFromJson(Map<String, dynamic> json) =>
    _RiderProfileModel(
      id: (json['id'] as num).toInt(),
      fullName: json['fullName'] as String,
      email: json['email'] as String,
      phoneNumber: json['phoneNumber'] as String,
      createdAt: DateTime.parse(json['createdAt'] as String),
      riderProfile: json['riderProfile'] == null
          ? null
          : RiderProfileDto.fromJson(
              json['riderProfile'] as Map<String, dynamic>,
            ),
    );

Map<String, dynamic> _$RiderProfileModelToJson(_RiderProfileModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'fullName': instance.fullName,
      'email': instance.email,
      'phoneNumber': instance.phoneNumber,
      'createdAt': instance.createdAt.toIso8601String(),
      'riderProfile': instance.riderProfile,
    };

_RiderProfileDto _$RiderProfileDtoFromJson(Map<String, dynamic> json) =>
    _RiderProfileDto(
      ratingAvg: (json['ratingAvg'] as num?)?.toDouble(),
      ratingCount: (json['ratingCount'] as num?)?.toInt(),
      canceledTripsCount: (json['canceledTripsCount'] as num?)?.toInt(),
    );

Map<String, dynamic> _$RiderProfileDtoToJson(_RiderProfileDto instance) =>
    <String, dynamic>{
      'ratingAvg': instance.ratingAvg,
      'ratingCount': instance.ratingCount,
      'canceledTripsCount': instance.canceledTripsCount,
    };
